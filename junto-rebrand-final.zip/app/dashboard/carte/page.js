'use client'

/**
 * ============================================
 * PAGE MA CARTE - JUNTO BRAND
 * ============================================
 * LOGIQUE 100% IDENTIQUE
 */

import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { COLORS, FOUR_DOTS, RADIUS, getAvatarColor, AMBIANCE_CONFIG, POSITION_CONFIG } from '@/app/lib/design-tokens'

export default function MaCartePage() {
  const router = useRouter()
  const cardRef = useRef(null)
  
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  
  const [activeTab, setActiveTab] = useState('stats')
  const [showTournamentMode, setShowTournamentMode] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [qrCodeUrl, setQrCodeUrl] = useState(null)
  
  const [stats, setStats] = useState({ matchesPlayed: 0, wins: 0, losses: 0, winRate: 0, organized: 0, partners: 0, favorites: 0 })
  const [userBadges, setUserBadges] = useState([])
  const [allBadgesCount, setAllBadgesCount] = useState(15)

  useEffect(() => { loadData() }, [])

  async function loadData() {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) { router.push('/auth'); return }
    setUser(session.user)

    const { data: profileData } = await supabase.from('profiles').select('*').eq('id', session.user.id).single()
    setProfile(profileData)

    const today = new Date().toISOString().split('T')[0]

    const { data: participations } = await supabase.from('match_participants')
      .select(`match_id, team, matches!inner (id, match_date, winner)`)
      .eq('user_id', session.user.id).eq('status', 'confirmed').lt('matches.match_date', today)

    const matchesPlayed = participations?.length || 0
    let wins = 0, losses = 0
    ;(participations || []).forEach(p => {
      if (p.matches?.winner) {
        if (p.team === p.matches.winner) wins++
        else losses++
      }
    })

    const { count: organizedCount } = await supabase.from('matches').select('*', { count: 'exact', head: true }).eq('organizer_id', session.user.id)
    const { count: partnersCount } = await supabase.from('match_participants').select('user_id', { count: 'exact', head: true }).eq('status', 'confirmed').neq('user_id', session.user.id)
    const { count: favoritesCount } = await supabase.from('player_favorites').select('*', { count: 'exact', head: true }).eq('favorite_user_id', session.user.id)

    setStats({
      matchesPlayed,
      wins,
      losses,
      winRate: matchesPlayed > 0 ? Math.round((wins / matchesPlayed) * 100) : 0,
      organized: organizedCount || 0,
      partners: partnersCount || 0,
      favorites: favoritesCount || 0
    })

    const { data: badges } = await supabase.from('user_badges').select('*, badge_definitions (*)').eq('user_id', session.user.id).order('unlocked_at', { ascending: false })
    setUserBadges(badges || [])

    try {
      const QRCode = (await import('qrcode')).default
      const url = await QRCode.toDataURL(`${window.location.origin}/player/${session.user.id}`, { width: 200, margin: 2, color: { dark: COLORS.ink, light: '#ffffff' } })
      setQrCodeUrl(url)
    } catch (err) { console.error('QR error:', err) }

    setLoading(false)
  }

  const profileUrl = typeof window !== 'undefined' ? `${window.location.origin}/player/${user?.id}` : ''

  async function shareProfile() {
    const shareText = `🎾 Découvre mon profil Junto !\n\n⭐ Niveau ${profile?.level}\n🏆 ${stats.wins} victoire${stats.wins > 1 ? 's' : ''}\n📍 ${profile?.city || 'Joueur de padel'}\n\n👉 ${profileUrl}`
    if (navigator.share) {
      try { await navigator.share({ title: `${profile?.name} - Junto`, text: shareText, url: profileUrl }); return } catch {}
    }
    window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`, '_blank')
  }

  async function copyLink() {
    try { await navigator.clipboard.writeText(profileUrl); setCopied(true); setTimeout(() => setCopied(false), 2000) }
    catch { alert('Impossible de copier le lien') }
  }

  async function downloadCard() {
    if (!cardRef.current) return
    setDownloading(true)
    try {
      const html2canvas = (await import('html2canvas')).default
      const canvas = await html2canvas(cardRef.current, { backgroundColor: COLORS.ink, scale: 2, useCORS: true, logging: false })
      const link = document.createElement('a')
      link.download = `carte-${profile?.name || 'joueur'}.png`
      link.href = canvas.toDataURL('image/png')
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (err) { await copyLink(); alert('Le lien de ton profil a été copié !') }
    finally { setDownloading(false) }
  }

  async function handleLogout() { await supabase.auth.signOut(); router.push('/auth') }

  const referralLink = typeof window !== 'undefined' ? `${window.location.origin}/join?ref=${user?.id?.slice(0, 8)}` : ''

  async function shareReferral() {
    const text = `🎾 Rejoins-moi sur Junto, l'app pour organiser des parties de padel entre potes !\n\n👉 ${referralLink}`
    if (navigator.share) { try { await navigator.share({ title: 'Rejoins Junto !', text, url: referralLink }); return } catch {} }
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank')
  }

  const avatarColor = FOUR_DOTS.colors[0]
  const ambiance = AMBIANCE_CONFIG[profile?.ambiance] || AMBIANCE_CONFIG.mix
  const position = POSITION_CONFIG[profile?.position] || POSITION_CONFIG.both

  if (loading) {
    return (
      <div style={{ padding: 40, textAlign: 'center' }}>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 16 }}>
          {FOUR_DOTS.colors.map((c, i) => <div key={i} className="junto-loading-dot" style={{ width: 12, height: 12, borderRadius: '50%', background: c }} />)}
        </div>
        <div style={{ color: COLORS.gray }}>Chargement...</div>
      </div>
    )
  }

  // === MODAL PARTAGE JUNTO ===
  if (showShareModal) {
    return (
      <div onClick={() => setShowShareModal(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', zIndex: 9999, padding: 24 }}>
        <div onClick={e => e.stopPropagation()} style={{ background: COLORS.white, borderRadius: 28, padding: 28, width: '100%', maxWidth: 340, textAlign: 'center' }}>
          <div style={{ marginBottom: 24 }}>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginBottom: 12 }}>
              {FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: c }} />)}
            </div>
            <h2 style={{ fontSize: 22, fontWeight: 700, color: COLORS.ink, margin: '0 0 6px' }}>Partager ma carte</h2>
            <p style={{ fontSize: 14, color: COLORS.gray, margin: 0 }}>Scanne ou partage ton profil</p>
          </div>

          <div style={{ background: COLORS.white, borderRadius: 20, padding: 16, marginBottom: 20, display: 'inline-block', border: `2px solid ${COLORS.border}` }}>
            {qrCodeUrl ? <img src={qrCodeUrl} alt="QR Code" style={{ width: 160, height: 160, display: 'block' }} /> : <div style={{ width: 160, height: 160, display: 'flex', alignItems: 'center', justifyContent: 'center', color: COLORS.gray }}>Génération...</div>}
          </div>

          <div style={{ background: COLORS.bgSoft, borderRadius: 16, padding: 14, marginBottom: 24, display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: profile?.avatar_url ? COLORS.bgSoft : avatarColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 700, color: COLORS.white, overflow: 'hidden' }}>
              {profile?.avatar_url ? <img src={profile.avatar_url} style={{ width: '100%', height: '100%', objectFit: 'cover' }} alt="" /> : profile?.name?.[0]?.toUpperCase()}
            </div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.ink }}>{profile?.name}</div>
              <div style={{ fontSize: 13, color: COLORS.gray }}>⭐ Niveau {profile?.level}</div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
            <button onClick={shareProfile} style={{ flex: 1, padding: 14, background: COLORS.primary, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 14, fontWeight: 700, cursor: 'pointer', fontFamily: "'Satoshi', sans-serif" }}>📤 Partager</button>
            <button onClick={copyLink} style={{ flex: 1, padding: 14, background: copied ? COLORS.teal : COLORS.bgSoft, color: copied ? COLORS.white : COLORS.ink, border: `2px solid ${COLORS.border}`, borderRadius: 100, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>{copied ? '✓ Copié' : '🔗 Lien'}</button>
          </div>

          <button onClick={downloadCard} disabled={downloading} style={{ width: '100%', padding: 14, background: COLORS.bgSoft, color: COLORS.gray, border: `2px solid ${COLORS.border}`, borderRadius: 100, fontSize: 14, fontWeight: 500, cursor: downloading ? 'wait' : 'pointer' }}>{downloading ? '⏳' : '📷'} Télécharger image</button>

          <button onClick={() => setShowShareModal(false)} style={{ marginTop: 20, background: 'none', border: 'none', color: COLORS.muted, fontSize: 14, cursor: 'pointer' }}>Fermer</button>
        </div>
      </div>
    )
  }

  // === MODE TOURNOI JUNTO ===
  if (showTournamentMode) {
    return (
      <div onClick={() => setShowTournamentMode(false)} style={{ position: 'fixed', inset: 0, background: '#000', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', zIndex: 9999, padding: 24, cursor: 'pointer' }}>
        <div style={{ background: COLORS.ink, borderRadius: 28, padding: 36, width: '100%', maxWidth: 340, textAlign: 'center' }}>
          <div style={{ width: 110, height: 110, borderRadius: 24, background: profile?.avatar_url ? COLORS.bgSoft : avatarColor, margin: '0 auto 24px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 48, fontWeight: 700, color: COLORS.white, border: `4px solid ${COLORS.primary}`, overflow: 'hidden' }}>
            {profile?.avatar_url ? <img src={profile.avatar_url} style={{ width: '100%', height: '100%', objectFit: 'cover' }} alt="" /> : profile?.name?.[0]?.toUpperCase()}
          </div>

          <h1 style={{ fontSize: 30, fontWeight: 800, color: COLORS.white, margin: '0 0 28px' }}>{profile?.name}</h1>

          <div style={{ background: `${COLORS.primary}20`, border: `3px solid ${COLORS.primary}`, borderRadius: 24, padding: '28px 48px', marginBottom: 28 }}>
            <div style={{ fontSize: 80, fontWeight: 900, color: COLORS.primary, lineHeight: 1 }}>{profile?.level || '?'}</div>
            <div style={{ fontSize: 15, color: COLORS.primary, marginTop: 10, fontWeight: 700, letterSpacing: 3 }}>NIVEAU</div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'center', gap: 14, marginBottom: 24 }}>
            <span style={{ background: 'rgba(255,255,255,0.1)', padding: '10px 18px', borderRadius: 12, color: 'rgba(255,255,255,0.85)', fontSize: 14, fontWeight: 500 }}>{position.emoji} {position.label}</span>
            <span style={{ background: `${ambiance.color}30`, padding: '10px 18px', borderRadius: 12, color: ambiance.color, fontSize: 14, fontWeight: 500 }}>{ambiance.emoji} {ambiance.label}</span>
          </div>

          {userBadges.length > 0 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: 10, marginTop: 20 }}>
              {userBadges.slice(0, 4).map(ub => (
                <div key={ub.badge_id} style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>{ub.badge_definitions?.emoji || '🏅'}</div>
              ))}
            </div>
          )}

          {qrCodeUrl && (
            <div style={{ marginTop: 24, paddingTop: 24, borderTop: '1px solid rgba(255,255,255,0.1)' }}>
              <div style={{ background: COLORS.white, borderRadius: 14, padding: 10, display: 'inline-block' }}>
                <img src={qrCodeUrl} alt="QR Code" style={{ width: 90, height: 90, display: 'block' }} />
              </div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 10 }}>Scanner pour voir mon profil</div>
            </div>
          )}
        </div>

        <div style={{ marginTop: 36, display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 15, color: 'rgba(255,255,255,0.5)', fontWeight: 600 }}>junto</span>
          <div style={{ display: 'flex', gap: 4 }}>{FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: c, opacity: 0.5 }} />)}</div>
        </div>
        <div style={{ marginTop: 16, fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>Tap pour fermer</div>
      </div>
    )
  }

  // === PAGE NORMALE JUNTO ===
  return (
    <div style={{ maxWidth: 500, margin: '0 auto', paddingBottom: 100 }}>
      
      {/* HERO - CARTE */}
      <div style={{ background: COLORS.ink, padding: '24px 20px 32px', position: 'relative', overflow: 'hidden', borderRadius: '0 0 32px 32px' }}>
        <div style={{ position: 'absolute', top: 20, right: 20, display: 'flex', gap: 6, opacity: 0.3 }}>
          {FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: c }} />)}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, position: 'relative', zIndex: 1 }}>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: COLORS.white, margin: 0, display: 'flex', alignItems: 'center', gap: 10 }}>🎴 Ma Carte</h1>
          <Link href="/dashboard/profile/edit" style={{ background: 'rgba(255,255,255,0.1)', border: 'none', borderRadius: 100, padding: '10px 18px', color: 'rgba(255,255,255,0.85)', fontSize: 14, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 8, fontWeight: 600 }}>✏️ Modifier</Link>
        </div>

        {/* Carte principale */}
        <div ref={cardRef} onClick={() => setShowTournamentMode(true)} style={{ background: `linear-gradient(145deg, ${COLORS.secondary} 0%, ${COLORS.ink} 100%)`, borderRadius: 24, padding: 24, cursor: 'pointer', border: `2px solid rgba(255,255,255,0.1)` }}>
          <div style={{ height: 4, background: `linear-gradient(90deg, ${COLORS.primary}, ${COLORS.amber}, ${COLORS.teal})`, borderRadius: 4, marginBottom: 20 }} />
          
          <div style={{ display: 'flex', gap: 18, alignItems: 'center', marginBottom: 20 }}>
            <div style={{ width: 80, height: 80, borderRadius: 20, background: profile?.avatar_url ? COLORS.bgSoft : avatarColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 34, fontWeight: 700, color: COLORS.white, border: `3px solid ${COLORS.primary}`, overflow: 'hidden', flexShrink: 0 }}>
              {profile?.avatar_url ? <img src={profile.avatar_url} style={{ width: '100%', height: '100%', objectFit: 'cover' }} alt="" /> : profile?.name?.[0]?.toUpperCase()}
            </div>
            <div>
              <h2 style={{ fontSize: 22, fontWeight: 700, color: COLORS.white, margin: '0 0 8px' }}>{profile?.name}</h2>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                <span style={{ background: `${COLORS.primary}30`, color: COLORS.primary, padding: '5px 12px', borderRadius: 10, fontSize: 13, fontWeight: 700 }}>⭐ Niveau {profile?.level}</span>
                {profile?.city && <span style={{ background: 'rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.8)', padding: '5px 12px', borderRadius: 10, fontSize: 13 }}>📍 {profile.city}</span>}
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
            <span style={{ background: 'rgba(255,255,255,0.1)', padding: '8px 14px', borderRadius: 10, fontSize: 13, color: 'rgba(255,255,255,0.8)' }}>{position.emoji} {position.label}</span>
            <span style={{ background: `${ambiance.color}25`, padding: '8px 14px', borderRadius: 10, fontSize: 13, color: ambiance.color }}>{ambiance.emoji} {ambiance.label}</span>
          </div>

          {userBadges.length > 0 && (
            <div style={{ display: 'flex', gap: 8, paddingTop: 16, borderTop: '1px solid rgba(255,255,255,0.1)' }}>
              {userBadges.slice(0, 5).map(ub => (
                <div key={ub.badge_id} style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>{ub.badge_definitions?.emoji || '🏅'}</div>
              ))}
              {userBadges.length > 5 && <div style={{ width: 36, height: 36, borderRadius: 10, background: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: 'rgba(255,255,255,0.6)' }}>+{userBadges.length - 5}</div>}
            </div>
          )}

          <div style={{ marginTop: 16, textAlign: 'center', fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>Tap pour mode tournoi 👆</div>
        </div>

        {/* Bouton Partager */}
        <button onClick={() => setShowShareModal(true)} style={{ width: '100%', marginTop: 20, padding: 16, background: COLORS.primary, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 16, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, fontFamily: "'Satoshi', sans-serif", boxShadow: `0 4px 20px ${COLORS.primaryGlow}` }}>
          📤 Partager ma carte
        </button>
      </div>

      {/* TABS */}
      <div style={{ padding: '0 16px', marginTop: 24 }}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 20, background: COLORS.bgSoft, padding: 4, borderRadius: 100 }}>
          {[{ id: 'stats', label: '📊 Stats' }, { id: 'badges', label: '🏆 Badges' }, { id: 'parrainage', label: '🎁 Parrainage' }].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
              flex: 1, padding: '12px 16px', border: 'none', borderRadius: 100,
              background: activeTab === tab.id ? COLORS.white : 'transparent',
              color: activeTab === tab.id ? COLORS.ink : COLORS.gray,
              fontSize: 13, fontWeight: 600, cursor: 'pointer',
              boxShadow: activeTab === tab.id ? '0 2px 8px rgba(0,0,0,0.08)' : 'none',
              fontFamily: "'Satoshi', sans-serif"
            }}>{tab.label}</button>
          ))}
        </div>

        {/* TAB STATS */}
        {activeTab === 'stats' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14 }}>
            {[
              { n: stats.matchesPlayed, l: 'Parties jouées', icon: '🎾', c: COLORS.primary },
              { n: stats.wins, l: 'Victoires', icon: '🏆', c: COLORS.teal },
              { n: `${stats.winRate}%`, l: 'Win rate', icon: '📈', c: COLORS.amber },
              { n: stats.organized, l: 'Organisées', icon: '👑', c: COLORS.secondary },
              { n: stats.partners, l: 'Partenaires', icon: '🤝', c: COLORS.teal },
              { n: stats.favorites, l: 'Fans', icon: '⭐', c: COLORS.amber }
            ].map((s, i) => (
              <div key={s.l} style={{ background: COLORS.white, borderRadius: 20, padding: 20, border: `2px solid ${COLORS.border}`, textAlign: 'center' }}>
                <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
                <div style={{ fontSize: 32, fontWeight: 800, color: s.c, marginBottom: 4 }}>{s.n}</div>
                <div style={{ fontSize: 13, color: COLORS.gray, fontWeight: 500 }}>{s.l}</div>
              </div>
            ))}
          </div>
        )}

        {/* TAB BADGES */}
        {activeTab === 'badges' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <span style={{ fontSize: 15, fontWeight: 600, color: COLORS.ink }}>{userBadges.length} / {allBadgesCount} badges</span>
              <Link href="/dashboard/me/badges" style={{ fontSize: 13, color: COLORS.primary, textDecoration: 'none', fontWeight: 600 }}>Voir tout →</Link>
            </div>
            {userBadges.length === 0 ? (
              <div style={{ textAlign: 'center', padding: 40, background: COLORS.bgSoft, borderRadius: 20 }}>
                <div style={{ fontSize: 48, marginBottom: 12 }}>🏅</div>
                <p style={{ color: COLORS.gray, fontSize: 14 }}>Joue des parties pour débloquer des badges !</p>
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
                {userBadges.slice(0, 6).map(ub => (
                  <div key={ub.badge_id} style={{ background: COLORS.white, borderRadius: 18, padding: 18, border: `2px solid ${COLORS.border}`, textAlign: 'center' }}>
                    <div style={{ fontSize: 36, marginBottom: 10 }}>{ub.badge_definitions?.emoji || '🏅'}</div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: COLORS.ink }}>{ub.badge_definitions?.name}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB PARRAINAGE */}
        {activeTab === 'parrainage' && (
          <div style={{ background: `linear-gradient(145deg, ${COLORS.tealSoft} 0%, ${COLORS.bgSoft} 100%)`, borderRadius: 24, padding: 28, textAlign: 'center', border: `2px solid ${COLORS.teal}30` }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>🎁</div>
            <h3 style={{ fontSize: 20, fontWeight: 700, color: COLORS.ink, marginBottom: 10 }}>Invite tes potes !</h3>
            <p style={{ fontSize: 14, color: COLORS.gray, marginBottom: 24, lineHeight: 1.6 }}>Partage Junto avec tes partenaires de jeu préférés et construis ta communauté</p>
            <button onClick={shareReferral} style={{ width: '100%', padding: 16, background: COLORS.teal, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 15, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, fontFamily: "'Satoshi', sans-serif" }}>
              📲 Inviter mes amis
            </button>
            <div style={{ marginTop: 16, padding: 14, background: COLORS.white, borderRadius: 14, fontSize: 13, color: COLORS.gray, wordBreak: 'break-all', border: `1px solid ${COLORS.border}` }}>{referralLink}</div>
          </div>
        )}
      </div>

      {/* RÉGLAGES */}
      <div style={{ padding: '24px 16px' }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, color: COLORS.gray, marginBottom: 14, textTransform: 'uppercase', letterSpacing: 1 }}>Réglages</h3>
        <div style={{ background: COLORS.white, borderRadius: 20, border: `2px solid ${COLORS.border}`, overflow: 'hidden' }}>
          {[
            { href: '/dashboard/profile/edit', icon: '✏️', label: 'Modifier mon profil' },
            { href: '/dashboard/settings/notifications', icon: '🔔', label: 'Notifications' },
            { href: '/dashboard/settings/privacy', icon: '🔒', label: 'Confidentialité' },
            { href: '/dashboard/settings/help', icon: '❓', label: 'Aide & Support' }
          ].map((item, i) => (
            <Link key={item.href} href={item.href} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '16px 18px', borderBottom: i < 3 ? `1px solid ${COLORS.border}` : 'none', textDecoration: 'none', color: COLORS.ink, fontSize: 15 }}>
              <span style={{ fontSize: 20 }}>{item.icon}</span>
              <span style={{ flex: 1, fontWeight: 500 }}>{item.label}</span>
              <span style={{ color: COLORS.muted }}>›</span>
            </Link>
          ))}
        </div>

        <button onClick={handleLogout} style={{ width: '100%', marginTop: 16, padding: 16, background: COLORS.primarySoft, color: COLORS.primary, border: 'none', borderRadius: 16, fontSize: 15, fontWeight: 600, cursor: 'pointer', fontFamily: "'Satoshi', sans-serif" }}>
          Déconnexion
        </button>
      </div>

      <style jsx global>{`
        @keyframes junto-loading { 0%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-12px); } }
        .junto-loading-dot { animation: junto-loading 1.4s ease-in-out infinite; }
        .junto-loading-dot:nth-child(1) { animation-delay: 0s; }
        .junto-loading-dot:nth-child(2) { animation-delay: 0.1s; }
        .junto-loading-dot:nth-child(3) { animation-delay: 0.2s; }
        .junto-loading-dot:nth-child(4) { animation-delay: 0.3s; }
      `}</style>
    </div>
  )
}
