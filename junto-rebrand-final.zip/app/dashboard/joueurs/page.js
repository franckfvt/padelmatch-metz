'use client'

/**
 * ============================================
 * PAGE JOUEURS - JUNTO BRAND
 * ============================================
 * LOGIQUE 100% IDENTIQUE
 */

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { COLORS, FOUR_DOTS, RADIUS, getAvatarColor } from '@/app/lib/design-tokens'

export default function JoueursPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const preselectedMatchId = searchParams.get('match')
  
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState([])
  const [isSearching, setIsSearching] = useState(false)
  const [activeTab, setActiveTab] = useState('favoris')
  const [levelFilter, setLevelFilter] = useState('all')
  
  const [favoritePlayers, setFavoritePlayers] = useState([])
  const [favoriteIds, setFavoriteIds] = useState(new Set())
  const [recentPlayers, setRecentPlayers] = useState([])
  const [nearbyPlayers, setNearbyPlayers] = useState([])
  
  const [incompleteMatch, setIncompleteMatch] = useState(null)
  const [matchPlayers, setMatchPlayers] = useState([])
  
  const [showInviteModal, setShowInviteModal] = useState(false)
  const [selectedPlayer, setSelectedPlayer] = useState(null)
  const [myOpenMatches, setMyOpenMatches] = useState([])
  const [inviting, setInviting] = useState(false)
  
  const [toast, setToast] = useState(null)
  const [matchesTogether, setMatchesTogether] = useState({})

  useEffect(() => { loadData() }, [])
  useEffect(() => { if (searchQuery.length >= 2) searchPlayers(); else { setSearchResults([]); setIsSearching(false) } }, [searchQuery])

  async function loadData() {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) { router.push('/auth'); return }
    setUser(session.user)

    const { data: profileData } = await supabase.from('profiles').select('*').eq('id', session.user.id).single()
    setProfile(profileData)

    const today = new Date().toISOString().split('T')[0]
    
    const { data: myMatches } = await supabase.from('matches')
      .select(`id, match_date, match_time, spots_available, city, status, clubs (name), match_participants (user_id, team, status, profiles:user_id (id, name, avatar_url))`)
      .eq('organizer_id', session.user.id).in('status', ['open', 'confirmed']).gt('spots_available', 0).gte('match_date', today)
      .order('match_date', { ascending: true }).limit(1)

    if (myMatches && myMatches.length > 0) {
      const match = myMatches[0]
      setIncompleteMatch(match)
      const confirmedPlayers = (match.match_participants || []).filter(p => p.status === 'confirmed' && p.profiles).map(p => ({ ...p.profiles, team: p.team }))
      setMatchPlayers(confirmedPlayers)
    }

    const { data: favoriteLinks } = await supabase.from('player_favorites').select('favorite_user_id').eq('user_id', session.user.id)
    let favoritesData = []
    const favIds = new Set((favoriteLinks || []).map(f => f.favorite_user_id))
    
    if (favIds.size > 0) {
      const { data: favProfiles } = await supabase.from('profiles').select('id, name, avatar_url, level, city, position').in('id', Array.from(favIds))
      favoritesData = favProfiles || []
    }
    
    setFavoriteIds(favIds)
    setFavoritePlayers(favoritesData)

    if (favIds.size > 0) {
      const matchesCount = {}
      for (const favId of favIds) {
        const { data: commonMatches } = await supabase.from('match_participants').select('match_id').eq('user_id', favId).eq('status', 'confirmed')
        if (commonMatches && commonMatches.length > 0) {
          const favMatchIds = commonMatches.map(m => m.match_id)
          const { count } = await supabase.from('match_participants').select('*', { count: 'exact', head: true }).eq('user_id', session.user.id).eq('status', 'confirmed').in('match_id', favMatchIds)
          matchesCount[favId] = count || 0
        } else { matchesCount[favId] = 0 }
      }
      setMatchesTogether(matchesCount)
    }

    if (favoritesData.length === 0) setActiveTab('pres')

    const { data: recentParticipations } = await supabase.from('match_participants').select(`match_id, matches!inner (id, match_date, organizer_id, match_participants (user_id, status, profiles:user_id (id, name, avatar_url, level, city, position)))`).eq('user_id', session.user.id).eq('status', 'confirmed').order('matches(match_date)', { ascending: false }).limit(20)

    const recentPlayersMap = new Map()
    ;(recentParticipations || []).forEach(p => {
      (p.matches?.match_participants || []).forEach(mp => {
        if (mp.user_id !== session.user.id && mp.profiles && !recentPlayersMap.has(mp.user_id)) {
          recentPlayersMap.set(mp.user_id, { ...mp.profiles, lastMatchDate: p.matches.match_date })
        }
      })
    })
    setRecentPlayers(Array.from(recentPlayersMap.values()).slice(0, 10))

    if (profileData?.city) {
      const { data: nearby } = await supabase.from('profiles').select('id, name, avatar_url, level, city, position').eq('city', profileData.city).neq('id', session.user.id).limit(20)
      setNearbyPlayers(nearby || [])
    }

    setLoading(false)
  }

  async function searchPlayers() {
    setIsSearching(true)
    const { data } = await supabase.from('profiles').select('id, name, avatar_url, level, city, position').ilike('name', `%${searchQuery}%`).neq('id', user?.id).limit(15)
    setSearchResults(data || [])
    setIsSearching(false)
  }

  async function toggleFavorite(playerId, e) {
    e?.stopPropagation()
    if (favoriteIds.has(playerId)) {
      await supabase.from('player_favorites').delete().eq('user_id', user.id).eq('favorite_user_id', playerId)
      setFavoriteIds(prev => { const n = new Set(prev); n.delete(playerId); return n })
      setFavoritePlayers(prev => prev.filter(p => p.id !== playerId))
    } else {
      await supabase.from('player_favorites').insert({ user_id: user.id, favorite_user_id: playerId })
      setFavoriteIds(prev => new Set([...prev, playerId]))
      const playerToAdd = [...searchResults, ...recentPlayers, ...nearbyPlayers].find(p => p.id === playerId)
      if (playerToAdd) setFavoritePlayers(prev => [...prev, playerToAdd])
    }
  }

  function openInviteModal(player, e) {
    e?.stopPropagation()
    setSelectedPlayer(player)
    loadOpenMatches()
    setShowInviteModal(true)
  }

  async function loadOpenMatches() {
    const today = new Date().toISOString().split('T')[0]
    const { data } = await supabase.from('matches').select('id, match_date, match_time, spots_available, city, clubs (name)').eq('organizer_id', user.id).gt('spots_available', 0).gte('match_date', today).order('match_date', { ascending: true })
    setMyOpenMatches(data || [])
  }

  async function inviteToMatch(matchId) {
    if (!selectedPlayer || inviting) return
    setInviting(true)
    try {
      await supabase.from('match_participants').insert({ match_id: matchId, user_id: selectedPlayer.id, status: 'invited', invited_by: user.id })
      const match = myOpenMatches.find(m => m.id === matchId)
      if (match && match.spots_available > 0) await supabase.from('matches').update({ spots_available: match.spots_available - 1 }).eq('id', matchId)
      const playerName = selectedPlayer.name?.split(' ')[0] || 'Le joueur'
      const matchDate = match ? formatMatchDate(match.match_date, match.match_time) : 'ta partie'
      setToast({ type: 'success', message: `✅ ${playerName} a été invité(e) pour ${matchDate} !` })
      setTimeout(() => setToast(null), 4000)
      setShowInviteModal(false)
      setSelectedPlayer(null)
      loadData()
    } catch (err) {
      setToast({ type: 'error', message: '❌ Erreur lors de l\'invitation' })
      setTimeout(() => setToast(null), 4000)
    } finally { setInviting(false) }
  }

  async function quickInvite(player, e) {
    e?.stopPropagation()
    if (!incompleteMatch) return
    setInviting(true)
    try {
      await supabase.from('match_participants').insert({ match_id: incompleteMatch.id, user_id: player.id, status: 'invited', invited_by: user.id })
      if (incompleteMatch.spots_available > 0) await supabase.from('matches').update({ spots_available: incompleteMatch.spots_available - 1 }).eq('id', incompleteMatch.id)
      setToast({ type: 'success', message: `✅ ${player.name?.split(' ')[0] || 'Le joueur'} a été invité(e) !` })
      setTimeout(() => setToast(null), 4000)
      loadData()
    } catch (err) {
      setToast({ type: 'error', message: '❌ Erreur lors de l\'invitation' })
      setTimeout(() => setToast(null), 4000)
    } finally { setInviting(false) }
  }

  function createMatchWithPlayer() {
    if (!selectedPlayer) return
    setShowInviteModal(false)
    router.push(`/dashboard/matches/create?invite=${selectedPlayer.id}`)
  }

  function formatMatchDate(dateStr, timeStr) {
    if (!dateStr) return 'Date flexible'
    const date = new Date(dateStr)
    const today = new Date()
    const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1)
    let dateText = date.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' })
    if (date.toDateString() === today.toDateString()) dateText = "Aujourd'hui"
    if (date.toDateString() === tomorrow.toDateString()) dateText = 'Demain'
    return `${dateText}${timeStr ? ' · ' + timeStr.slice(0,5) : ''}`
  }

  function formatRecentDate(dateStr) {
    if (!dateStr) return ''
    const date = new Date(dateStr)
    const diffDays = Math.floor((new Date() - date) / (1000 * 60 * 60 * 24))
    if (diffDays === 0) return 'Aujourd\'hui'
    if (diffDays === 1) return 'Hier'
    if (diffDays < 7) return `Il y a ${diffDays}j`
    if (diffDays < 30) return `Il y a ${Math.floor(diffDays / 7)} sem.`
    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })
  }

  function getFilteredNearbyPlayers() {
    if (levelFilter === 'all') return nearbyPlayers
    return nearbyPlayers.filter(p => {
      const level = p.level || 0
      switch (levelFilter) {
        case '3-4': return level >= 3 && level < 4.5
        case '4-5': return level >= 4 && level < 5.5
        case '5+': return level >= 5
        default: return true
      }
    })
  }

  // === LOADING JUNTO ===
  if (loading) {
    return (
      <div style={{ padding: 40, textAlign: 'center' }}>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 16 }}>
          {FOUR_DOTS.colors.map((c, i) => <div key={i} className="junto-loading-dot" style={{ width: 12, height: 12, borderRadius: '50%', background: c }} />)}
        </div>
        <div style={{ color: COLORS.gray }}>Chargement...</div>
      </div>
    )
  }

  const isNewUser = favoritePlayers.length === 0 && recentPlayers.length === 0
  let playersToShow = []
  if (searchQuery.length >= 2) playersToShow = searchResults
  else if (activeTab === 'favoris') playersToShow = favoritePlayers
  else if (activeTab === 'recents') playersToShow = recentPlayers
  else if (activeTab === 'pres') playersToShow = getFilteredNearbyPlayers()
  const spotsRemaining = incompleteMatch?.spots_available || 0

  // === AVATAR JUNTO ===
  function Avatar({ player, size = 48, index = 0, showBadge = false }) {
    const color = FOUR_DOTS.colors[index % 4]
    return (
      <div className="avatar-hover" style={{
        width: size, height: size, borderRadius: '50%',
        background: player?.avatar_url ? COLORS.bgSoft : color,
        border: `3px solid ${COLORS.white}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: size * 0.4, fontWeight: 700, color: COLORS.white,
        overflow: 'hidden', position: 'relative', boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        {player?.avatar_url ? <img src={player.avatar_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : player?.name?.[0]?.toUpperCase() || '?'}
        {showBadge && <div style={{ position: 'absolute', bottom: -2, left: '50%', transform: 'translateX(-50%)', background: COLORS.primary, color: COLORS.white, fontSize: 8, fontWeight: 700, padding: '2px 6px', borderRadius: 6 }}>Toi</div>}
      </div>
    )
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '0 16px' }}>
      
      {/* HERO CONTEXTUEL JUNTO */}
      {incompleteMatch && (
        <div style={{
          background: COLORS.ink,
          borderRadius: 24,
          padding: 24,
          marginBottom: 24,
          position: 'relative',
          overflow: 'hidden'
        }}>
          {/* Decoration dots */}
          <div style={{ position: 'absolute', top: 16, right: 16, display: 'flex', gap: 6, opacity: 0.3 }}>
            {FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: c }} />)}
          </div>

          <div style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 }}>
              🎾 Ta prochaine partie
            </div>
            <div style={{ fontSize: 32, fontWeight: 800, color: COLORS.white, marginBottom: 4 }}>
              {incompleteMatch.match_time?.slice(0, 5) || '--:--'}
            </div>
            <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.85)', marginBottom: 20 }}>
              {formatMatchDate(incompleteMatch.match_date)} · {incompleteMatch.clubs?.name || incompleteMatch.city || 'Lieu à définir'}
            </div>

            {/* 4 slots avec couleurs Junto */}
            <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginBottom: 20 }}>
              {[0, 1, 2, 3].map(i => {
                const player = matchPlayers[i]
                const isMe = player?.id === user?.id
                return (
                  <div key={i} style={{
                    width: 56, height: 56, borderRadius: '50%',
                    background: player ? FOUR_DOTS.colors[i] : 'rgba(255,255,255,0.1)',
                    border: player ? '3px solid rgba(255,255,255,0.3)' : '2px dashed rgba(255,255,255,0.4)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: player ? 20 : 24, fontWeight: 700,
                    color: player ? COLORS.white : 'rgba(255,255,255,0.4)',
                    position: 'relative', overflow: 'hidden'
                  }}>
                    {player ? (player.avatar_url ? <img src={player.avatar_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : player.name?.[0]?.toUpperCase()) : '+'}
                    {isMe && <div style={{ position: 'absolute', bottom: -2, left: '50%', transform: 'translateX(-50%)', background: COLORS.primary, color: COLORS.white, fontSize: 8, fontWeight: 700, padding: '2px 6px', borderRadius: 6 }}>Toi</div>}
                  </div>
                )
              })}
            </div>

            <div style={{ display: 'flex', justifyContent: 'center', gap: 6, alignItems: 'center' }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: COLORS.teal }} className="junto-dot" />
              <span style={{ fontSize: 14, color: COLORS.teal, fontWeight: 600 }}>{spotsRemaining} place{spotsRemaining > 1 ? 's' : ''} restante{spotsRemaining > 1 ? 's' : ''}</span>
            </div>
          </div>
        </div>
      )}

      {/* BARRE DE RECHERCHE */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ position: 'relative' }}>
          <span style={{ position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', fontSize: 18 }}>🔍</span>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher un joueur..."
            style={{
              width: '100%', padding: '16px 16px 16px 48px',
              border: `2px solid ${COLORS.border}`, borderRadius: 16,
              fontSize: 15, fontFamily: "'Satoshi', sans-serif",
              background: COLORS.white, outline: 'none'
            }}
          />
          {isSearching && <div style={{ position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)', fontSize: 12, color: COLORS.gray }}>...</div>}
        </div>
      </div>

      {/* TABS */}
      {searchQuery.length < 2 && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 20, overflowX: 'auto', paddingBottom: 4 }}>
          {[
            { id: 'favoris', label: '⭐ Favoris', count: favoritePlayers.length },
            { id: 'recents', label: '🕐 Récents', count: recentPlayers.length },
            { id: 'pres', label: `📍 ${profile?.city || 'Près de toi'}`, count: nearbyPlayers.length }
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
              padding: '10px 18px',
              background: activeTab === tab.id ? COLORS.ink : COLORS.white,
              color: activeTab === tab.id ? COLORS.white : COLORS.gray,
              border: `2px solid ${activeTab === tab.id ? COLORS.ink : COLORS.border}`,
              borderRadius: 100, fontSize: 13, fontWeight: 600, cursor: 'pointer',
              whiteSpace: 'nowrap', fontFamily: "'Satoshi', sans-serif",
              display: 'flex', alignItems: 'center', gap: 8
            }}>
              {tab.label}
              <span style={{
                background: activeTab === tab.id ? 'rgba(255,255,255,0.2)' : COLORS.bgSoft,
                padding: '2px 8px', borderRadius: 100, fontSize: 11
              }}>{tab.count}</span>
            </button>
          ))}
        </div>
      )}

      {/* EMPTY STATE */}
      {playersToShow.length === 0 && !isSearching && (
        <div style={{ textAlign: 'center', padding: 40, background: COLORS.bgSoft, borderRadius: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginBottom: 16, opacity: 0.4 }}>
            {FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 10, height: 10, borderRadius: '50%', background: c }} />)}
          </div>
          <h3 style={{ fontSize: 18, fontWeight: 700, color: COLORS.ink, marginBottom: 8 }}>
            {searchQuery.length >= 2 ? 'Aucun résultat' : activeTab === 'favoris' ? 'Pas encore de favoris' : activeTab === 'recents' ? 'Pas encore de récents' : 'Aucun joueur trouvé'}
          </h3>
          <p style={{ fontSize: 14, color: COLORS.gray }}>
            {searchQuery.length >= 2 ? 'Essaie un autre nom' : 'Joue des parties pour rencontrer des joueurs !'}
          </p>
        </div>
      )}

      {/* LISTE DES JOUEURS */}
      {activeTab === 'favoris' && searchQuery.length < 2 && playersToShow.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {playersToShow.map((player, i) => {
            const partiesTogether = matchesTogether[player.id] || 0
            return (
              <div key={player.id} onClick={() => router.push(`/player/${player.id}`)} style={{
                background: COLORS.white, borderRadius: 16, padding: 16,
                border: `2px solid ${COLORS.border}`, cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 14,
                transition: 'all 0.2s'
              }}>
                <Avatar player={player} size={52} index={i} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                    <span style={{ fontWeight: 700, color: COLORS.ink, fontSize: 15 }}>{player.name}</span>
                    <span style={{ fontSize: 14, color: COLORS.amber }}>⭐</span>
                  </div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <span style={{ background: COLORS.primarySoft, color: COLORS.primary, padding: '3px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600 }}>Niv. {player.level || '?'}</span>
                    {player.city && <span style={{ background: COLORS.bgSoft, color: COLORS.gray, padding: '3px 10px', borderRadius: 8, fontSize: 11 }}>{player.city}</span>}
                    {partiesTogether > 0 && <span style={{ background: COLORS.tealSoft, color: COLORS.teal, padding: '3px 10px', borderRadius: 8, fontSize: 11, fontWeight: 500 }}>🎾 {partiesTogether} partie{partiesTogether > 1 ? 's' : ''}</span>}
                  </div>
                </div>
                <button onClick={(e) => incompleteMatch && spotsRemaining > 0 ? quickInvite(player, e) : openInviteModal(player, e)} style={{
                  padding: '12px 20px', background: COLORS.primary, color: COLORS.white,
                  border: 'none', borderRadius: 100, fontSize: 13, fontWeight: 700, cursor: 'pointer',
                  fontFamily: "'Satoshi', sans-serif", boxShadow: `0 4px 12px ${COLORS.primaryGlow}`
                }}>{incompleteMatch && spotsRemaining > 0 ? '+ Inviter' : 'Inviter'}</button>
              </div>
            )
          })}
        </div>
      )}

      {/* MODE GRILLE POUR NEARBY */}
      {activeTab === 'pres' && searchQuery.length < 2 && playersToShow.length > 0 && (
        <>
          <div style={{ display: 'flex', gap: 8, marginBottom: 16, overflowX: 'auto' }}>
            {[{ id: 'all', label: 'Tous' }, { id: '3-4', label: '3-4' }, { id: '4-5', label: '4-5' }, { id: '5+', label: '5+' }].map(f => (
              <button key={f.id} onClick={() => setLevelFilter(f.id)} style={{
                padding: '8px 14px',
                background: levelFilter === f.id ? COLORS.primary : COLORS.white,
                color: levelFilter === f.id ? COLORS.white : COLORS.gray,
                border: `2px solid ${levelFilter === f.id ? COLORS.primary : COLORS.border}`,
                borderRadius: 100, fontSize: 12, fontWeight: 600, cursor: 'pointer'
              }}>{f.label}</button>
            ))}
          </div>
          <div className="players-grid">
            {playersToShow.map((player, i) => (
              <div key={player.id} onClick={() => router.push(`/player/${player.id}`)} style={{
                background: COLORS.white, borderRadius: 18, padding: 16,
                border: `2px solid ${COLORS.border}`, cursor: 'pointer', position: 'relative'
              }}>
                <button onClick={(e) => toggleFavorite(player.id, e)} style={{
                  position: 'absolute', top: 10, right: 10, width: 32, height: 32,
                  background: favoriteIds.has(player.id) ? COLORS.amberSoft : COLORS.bgSoft,
                  border: 'none', borderRadius: '50%', fontSize: 14, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center'
                }}>{favoriteIds.has(player.id) ? '⭐' : '☆'}</button>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
                  <Avatar player={player} size={56} index={i} />
                  <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.ink, marginTop: 12, marginBottom: 8, maxWidth: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{player.name}</div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 12 }}>
                    <span style={{ background: COLORS.primarySoft, color: COLORS.primary, padding: '3px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600 }}>⭐ {player.level || '?'}</span>
                  </div>
                  <button onClick={(e) => incompleteMatch && spotsRemaining > 0 ? quickInvite(player, e) : openInviteModal(player, e)} style={{
                    width: '100%', padding: 10, background: COLORS.primary, color: COLORS.white,
                    border: 'none', borderRadius: 100, fontSize: 12, fontWeight: 700, cursor: 'pointer'
                  }}>{incompleteMatch && spotsRemaining > 0 ? '+ Inviter' : 'Inviter'}</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* RECENTS */}
      {activeTab === 'recents' && searchQuery.length < 2 && playersToShow.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {playersToShow.map((player, i) => (
            <div key={player.id} onClick={() => router.push(`/player/${player.id}`)} style={{
              background: COLORS.white, borderRadius: 16, padding: 16,
              border: `2px solid ${COLORS.border}`, cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 14
            }}>
              <Avatar player={player} size={52} index={i} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, color: COLORS.ink, fontSize: 15, marginBottom: 4 }}>{player.name}</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  <span style={{ background: COLORS.primarySoft, color: COLORS.primary, padding: '3px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600 }}>Niv. {player.level || '?'}</span>
                  {player.lastMatchDate && <span style={{ background: COLORS.tealSoft, color: COLORS.teal, padding: '3px 10px', borderRadius: 8, fontSize: 11 }}>🎾 {formatRecentDate(player.lastMatchDate)}</span>}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {!favoriteIds.has(player.id) && <button onClick={(e) => toggleFavorite(player.id, e)} style={{ width: 40, height: 40, background: COLORS.bgSoft, border: `2px solid ${COLORS.border}`, borderRadius: 12, fontSize: 18, cursor: 'pointer' }}>☆</button>}
                <button onClick={(e) => incompleteMatch && spotsRemaining > 0 ? quickInvite(player, e) : openInviteModal(player, e)} style={{
                  padding: '12px 20px', background: COLORS.primary, color: COLORS.white,
                  border: 'none', borderRadius: 100, fontSize: 13, fontWeight: 700, cursor: 'pointer'
                }}>{incompleteMatch && spotsRemaining > 0 ? '+ Inviter' : 'Inviter'}</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SEARCH RESULTS */}
      {searchQuery.length >= 2 && playersToShow.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {playersToShow.map((player, i) => (
            <div key={player.id} onClick={() => router.push(`/player/${player.id}`)} style={{
              background: COLORS.white, borderRadius: 16, padding: 16,
              border: `2px solid ${COLORS.border}`, cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 14
            }}>
              <Avatar player={player} size={52} index={i} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, color: COLORS.ink, fontSize: 15, marginBottom: 4 }}>{player.name}</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  <span style={{ background: COLORS.primarySoft, color: COLORS.primary, padding: '3px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600 }}>Niv. {player.level || '?'}</span>
                  {player.city && <span style={{ background: COLORS.bgSoft, color: COLORS.gray, padding: '3px 10px', borderRadius: 8, fontSize: 11 }}>{player.city}</span>}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={(e) => toggleFavorite(player.id, e)} style={{ width: 40, height: 40, background: favoriteIds.has(player.id) ? COLORS.amberSoft : COLORS.bgSoft, border: `2px solid ${COLORS.border}`, borderRadius: 12, fontSize: 18, cursor: 'pointer' }}>{favoriteIds.has(player.id) ? '⭐' : '☆'}</button>
                <button onClick={(e) => incompleteMatch && spotsRemaining > 0 ? quickInvite(player, e) : openInviteModal(player, e)} style={{
                  padding: '12px 20px', background: COLORS.primary, color: COLORS.white,
                  border: 'none', borderRadius: 100, fontSize: 13, fontWeight: 700, cursor: 'pointer'
                }}>{incompleteMatch && spotsRemaining > 0 ? '+ Inviter' : 'Inviter'}</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MODAL INVITATION JUNTO */}
      {showInviteModal && selectedPlayer && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }} onClick={() => setShowInviteModal(false)}>
          <div style={{ background: COLORS.white, borderRadius: 24, padding: 28, width: '100%', maxWidth: 420, maxHeight: '80vh', overflow: 'auto' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <h3 style={{ fontSize: 20, fontWeight: 700, margin: 0, color: COLORS.ink }}>Inviter {selectedPlayer.name?.split(' ')[0]}</h3>
              <button onClick={() => setShowInviteModal(false)} style={{ background: COLORS.bgSoft, border: 'none', width: 36, height: 36, borderRadius: 12, fontSize: 20, cursor: 'pointer', color: COLORS.gray }}>×</button>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 18, background: COLORS.bgSoft, borderRadius: 18, marginBottom: 24 }}>
              <Avatar player={selectedPlayer} size={56} index={0} />
              <div>
                <div style={{ fontWeight: 700, color: COLORS.ink, fontSize: 16 }}>{selectedPlayer.name}</div>
                <div style={{ fontSize: 14, color: COLORS.gray }}>⭐ Niveau {selectedPlayer.level || '?'} · {selectedPlayer.city || ''}</div>
              </div>
            </div>

            {myOpenMatches.length > 0 && (
              <div style={{ marginBottom: 24 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.gray, marginBottom: 12 }}>Tes parties avec des places :</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {myOpenMatches.map(match => (
                    <div key={match.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: 14, background: COLORS.bgSoft, borderRadius: 14, border: `2px solid ${COLORS.border}` }}>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.ink }}>{formatMatchDate(match.match_date, match.match_time)}</div>
                        <div style={{ fontSize: 12, color: COLORS.gray }}>{match.clubs?.name || match.city || 'Lieu'} · {match.spots_available} place{match.spots_available > 1 ? 's' : ''}</div>
                      </div>
                      <button onClick={() => inviteToMatch(match.id)} disabled={inviting} style={{
                        padding: '10px 18px', background: COLORS.primary, color: COLORS.white,
                        border: 'none', borderRadius: 100, fontSize: 13, fontWeight: 700, cursor: inviting ? 'not-allowed' : 'pointer', opacity: inviting ? 0.7 : 1
                      }}>+ Ajouter</button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {myOpenMatches.length > 0 && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
                <div style={{ flex: 1, height: 1, background: COLORS.border }} />
                <span style={{ fontSize: 13, color: COLORS.muted }}>ou</span>
                <div style={{ flex: 1, height: 1, background: COLORS.border }} />
              </div>
            )}

            <button onClick={createMatchWithPlayer} style={{
              width: '100%', padding: 16, background: COLORS.teal, color: COLORS.white,
              border: 'none', borderRadius: 100, fontSize: 15, fontWeight: 700, cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              fontFamily: "'Satoshi', sans-serif"
            }}>🆕 Créer une partie avec {selectedPlayer.name?.split(' ')[0]}</button>
          </div>
        </div>
      )}

      {/* TOAST JUNTO */}
      {toast && (
        <div style={{
          position: 'fixed', bottom: 100, left: '50%', transform: 'translateX(-50%)',
          background: toast.type === 'success' ? COLORS.teal : COLORS.primary,
          color: COLORS.white, padding: '16px 28px', borderRadius: 100,
          fontSize: 14, fontWeight: 600, boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
          zIndex: 2000, maxWidth: '90%', textAlign: 'center'
        }}>{toast.message}</div>
      )}

      <div style={{ height: 100 }} />

      <style jsx global>{`
        @keyframes junto-breathe { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.4); } }
        .junto-dot { animation: junto-breathe 3s ease-in-out infinite; }
        @keyframes junto-loading { 0%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-12px); } }
        .junto-loading-dot { animation: junto-loading 1.4s ease-in-out infinite; }
        .junto-loading-dot:nth-child(1) { animation-delay: 0s; }
        .junto-loading-dot:nth-child(2) { animation-delay: 0.1s; }
        .junto-loading-dot:nth-child(3) { animation-delay: 0.2s; }
        .junto-loading-dot:nth-child(4) { animation-delay: 0.3s; }
        .avatar-hover { transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
        .avatar-hover:hover { transform: translateY(-4px) scale(1.05); }
        .players-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; }
        @media (min-width: 640px) { .players-grid { grid-template-columns: repeat(3, 1fr); gap: 16px; } }
        @media (min-width: 1024px) { .players-grid { grid-template-columns: repeat(4, 1fr); } }
        input:focus { border-color: ${COLORS.primary} !important; }
      `}</style>
    </div>
  )
}
