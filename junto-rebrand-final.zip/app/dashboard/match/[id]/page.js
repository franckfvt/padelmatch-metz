'use client'

/**
 * PAGE MATCH DETAIL - JUNTO BRAND
 * LOGIQUE 100% IDENTIQUE
 */

import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter, useParams } from 'next/navigation'
import Link from 'next/link'
import { COLORS, FOUR_DOTS, AMBIANCE_CONFIG } from '@/app/lib/design-tokens'

// Avatar Junto
function Avatar({ name, size = 40, empty = false, avatarUrl = null, onClick, index = 0 }) {
  const color = FOUR_DOTS.colors[index % 4]
  if (empty || !name) {
    return <div style={{ width: size, height: size, borderRadius: '50%', border: '2px dashed rgba(255,255,255,0.4)', background: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.4, color: 'rgba(255,255,255,0.6)', flexShrink: 0 }}>+</div>
  }
  if (avatarUrl) {
    return <img src={avatarUrl} alt={name} onClick={onClick} style={{ width: size, height: size, borderRadius: '50%', objectFit: 'cover', border: `3px solid ${color}`, boxShadow: '0 2px 8px rgba(0,0,0,0.2)', cursor: onClick ? 'pointer' : 'default', flexShrink: 0 }} />
  }
  return <div onClick={onClick} style={{ width: size, height: size, borderRadius: '50%', background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size * 0.4, fontWeight: 700, color: '#fff', border: '3px solid rgba(255,255,255,0.3)', boxShadow: '0 2px 8px rgba(0,0,0,0.2)', cursor: onClick ? 'pointer' : 'default', flexShrink: 0 }}>{name[0].toUpperCase()}</div>
}

// Carte joueur sur le terrain
function PlayerCard({ player, position, onClickPlayer, onClickEmpty, index = 0 }) {
  const isEmpty = !player
  const isPendingInvite = player?.isPendingInvite
  const profile = player?.profiles || player
  const color = FOUR_DOTS.colors[index % 4]

  if (isEmpty) {
    return (
      <div onClick={onClickEmpty} style={{ background: 'rgba(255,255,255,0.05)', border: '2px dashed rgba(255,255,255,0.25)', borderRadius: 16, padding: '14px 10px', textAlign: 'center', cursor: onClickEmpty ? 'pointer' : 'default', minWidth: 90 }}>
        <div style={{ width: 48, height: 48, borderRadius: '50%', border: '2px dashed rgba(255,255,255,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 8px', fontSize: 20, color: 'rgba(255,255,255,0.5)' }}>+</div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>Place libre</div>
      </div>
    )
  }

  if (isPendingInvite) {
    return (
      <div style={{ background: `${COLORS.amber}20`, border: `2px dashed ${COLORS.amber}60`, borderRadius: 16, padding: '14px 10px', textAlign: 'center', minWidth: 90 }}>
        <div style={{ width: 48, height: 48, borderRadius: '50%', border: `2px dashed ${COLORS.amber}`, background: `${COLORS.amber}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 8px', fontSize: 18, fontWeight: 700, color: COLORS.amber }}>{player.name?.[0]?.toUpperCase() || '?'}</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#fff' }}>{player.name?.split(' ')[0] || 'Invité'}</div>
        <div style={{ fontSize: 10, color: COLORS.amber, marginTop: 2 }}>⏳ En attente</div>
      </div>
    )
  }

  return (
    <div onClick={() => onClickPlayer?.(profile)} style={{ background: 'rgba(255,255,255,0.1)', border: `2px solid ${color}50`, borderRadius: 16, padding: '14px 10px', textAlign: 'center', cursor: onClickPlayer ? 'pointer' : 'default', minWidth: 90 }}>
      <Avatar name={profile?.name} size={48} avatarUrl={profile?.avatar_url} index={index} />
      <div style={{ fontSize: 13, fontWeight: 600, color: '#fff', marginTop: 8 }}>{profile?.name?.split(' ')[0]}</div>
      <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', marginTop: 2 }}>Niv. {profile?.level || '?'}</div>
      {player.isOrganizer && <div style={{ fontSize: 9, color: COLORS.amber, marginTop: 4, fontWeight: 600 }}>👑 ORGA</div>}
    </div>
  )
}

export default function MatchDetailPage() {
  const router = useRouter()
  const { id: matchId } = useParams()
  const messagesEndRef = useRef(null)

  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [match, setMatch] = useState(null)
  const [loading, setLoading] = useState(true)
  const [participants, setParticipants] = useState([])
  const [pendingRequests, setPendingRequests] = useState([])
  const [pendingInvites, setPendingInvites] = useState([])
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState('')
  const [modal, setModal] = useState(null)
  const [joinTeam, setJoinTeam] = useState('A')
  const [selectedPlayer, setSelectedPlayer] = useState(null)

  useEffect(() => { loadData() }, [matchId])
  useEffect(() => {
    const channel = supabase.channel(`match-${matchId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'match_messages', filter: `match_id=eq.${matchId}` }, () => loadMessages())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'match_participants', filter: `match_id=eq.${matchId}` }, () => loadData())
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [matchId])
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  async function loadData() {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (!session) { router.push('/auth'); return }
      setUser(session.user)

      const { data: profileData } = await supabase.from('profiles').select('*').eq('id', session.user.id).single()
      setProfile(profileData)

      const { data: matchData } = await supabase.from('matches').select(`*, clubs (id, name, address), profiles!matches_organizer_id_fkey (id, name, level, position, avatar_url, phone)`).eq('id', matchId).single()
      if (!matchData) { router.push('/dashboard/parties'); return }
      setMatch(matchData)

      const { data: participantsData } = await supabase.from('match_participants').select(`*, profiles!match_participants_user_id_fkey (id, name, level, position, avatar_url)`).eq('match_id', matchId).in('status', ['confirmed', 'pending'])
      setParticipants(participantsData || [])

      const { data: invitesData } = await supabase.from('pending_invites').select('*').eq('match_id', matchId).eq('status', 'pending')
      setPendingInvites(invitesData || [])

      if (matchData.organizer_id === session.user.id) {
        const { data: pendingData } = await supabase.from('match_participants').select(`*, profiles!match_participants_user_id_fkey (id, name, level, position, avatar_url)`).eq('match_id', matchId).eq('status', 'pending')
        setPendingRequests(pendingData || [])
      }

      await loadMessages()
      setLoading(false)
    } catch (error) { console.error('Error:', error); setLoading(false) }
  }

  async function loadMessages() {
    const { data } = await supabase.from('match_messages').select(`*, profiles (id, name, avatar_url)`).eq('match_id', matchId).order('created_at', { ascending: true }).limit(100)
    setMessages(data || [])
  }

  const isOrganizer = () => match?.organizer_id === user?.id
  const isParticipant = () => participants.some(p => p.user_id === user?.id && p.status === 'confirmed')
  const pricePerPerson = match?.price_total ? Math.round(match.price_total / 100 / 4) : 0
  const confirmedParticipants = participants.filter(p => p.status === 'confirmed')
  const pendingParticipants = participants.filter(p => p.status === 'pending')
  function getPlayerCount() { return confirmedParticipants.length + 1 + pendingInvites.length }
  function getSpotsLeft() { return Math.max(0, 4 - getPlayerCount()) }
  function formatDate(dateStr) { return dateStr ? new Date(dateStr).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }) : 'Date à définir' }
  function formatDateShort(dateStr) { return dateStr ? new Date(dateStr).toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric' }) : '—' }
  function formatTime(timeStr) { return timeStr ? timeStr.slice(0, 5) : '--:--' }

  const orgaPlayer = { isOrganizer: true, profiles: match?.profiles, team: match?.organizer_team || 'A', status: 'confirmed', user_id: match?.organizer_id }
  const allPlayers = [orgaPlayer, ...confirmedParticipants, ...pendingInvites.map(i => ({ ...i, isPendingInvite: true }))]
  const teamA = allPlayers.filter(p => p.team === 'A')
  const teamB = allPlayers.filter(p => p.team === 'B')
  const ambiance = AMBIANCE_CONFIG[match?.ambiance] || AMBIANCE_CONFIG.mix

  async function sendMessage(e) {
    e.preventDefault()
    if (!newMessage.trim()) return
    const messageText = newMessage.trim()
    setMessages(prev => [...prev, { id: Date.now(), match_id: parseInt(matchId), user_id: user.id, message: messageText, created_at: new Date().toISOString(), profiles: { id: user.id, name: profile?.name, avatar_url: profile?.avatar_url } }])
    setNewMessage('')
    await supabase.from('match_messages').insert({ match_id: parseInt(matchId), user_id: user.id, message: messageText })
  }

  async function requestToJoin() {
    await supabase.from('match_participants').insert({ match_id: parseInt(matchId), user_id: user.id, team: joinTeam, status: 'pending' })
    setModal(null)
    loadData()
  }

  async function acceptRequest(req) {
    await supabase.from('match_participants').update({ status: 'confirmed' }).eq('id', req.id)
    loadData()
  }

  async function refuseRequest(req) {
    await supabase.from('match_participants').delete().eq('id', req.id)
    loadData()
  }

  async function cancelInvite(invite) {
    await supabase.from('pending_invites').delete().eq('id', invite.id)
    loadData()
  }

  async function leaveMatch() {
    await supabase.from('match_participants').delete().eq('match_id', parseInt(matchId)).eq('user_id', user.id)
    setModal(null)
    loadData()
  }

  async function cancelMatch() {
    await supabase.from('matches').update({ status: 'cancelled' }).eq('id', parseInt(matchId))
    setModal(null)
    router.push('/dashboard/parties')
  }

  if (loading) {
    return (
      <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 16 }}>
            {FOUR_DOTS.colors.map((c, i) => <div key={i} className="junto-loading-dot" style={{ width: 14, height: 14, borderRadius: '50%', background: c }} />)}
          </div>
          <div style={{ color: COLORS.gray }}>Chargement...</div>
        </div>
      </div>
    )
  }

  if (!match) {
    return (
      <div style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginBottom: 16, opacity: 0.4 }}>
            {FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 10, height: 10, borderRadius: '50%', background: c }} />)}
          </div>
          <div style={{ color: COLORS.gray, marginBottom: 16 }}>Partie introuvable</div>
          <Link href="/dashboard/parties" style={{ color: COLORS.primary, fontWeight: 600 }}>← Retour aux parties</Link>
        </div>
      </div>
    )
  }

  const canJoin = !isOrganizer() && !isParticipant() && !pendingParticipants.some(p => p.user_id === user?.id) && getSpotsLeft() > 0 && match.status === 'open'

  return (
    <div style={{ fontFamily: "'Satoshi', sans-serif", background: COLORS.bg, minHeight: '100vh', padding: '16px' }}>
      <div className="page-container">
        <div className="main-column">
          
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <Link href="/dashboard/parties" style={{ fontSize: 14, color: COLORS.gray, textDecoration: 'none', fontWeight: 500 }}>← Retour</Link>
            {(() => {
              const spots = getSpotsLeft()
              if (match.status === 'cancelled') return <span style={{ background: COLORS.primarySoft, color: COLORS.primary, padding: '6px 14px', borderRadius: 100, fontSize: 12, fontWeight: 600 }}>❌ Annulée</span>
              if (match.status === 'completed') return <span style={{ background: COLORS.tealSoft, color: COLORS.teal, padding: '6px 14px', borderRadius: 100, fontSize: 12, fontWeight: 600 }}>✅ Terminée</span>
              if (spots === 0) return <span style={{ background: COLORS.bgSoft, color: COLORS.gray, padding: '6px 14px', borderRadius: 100, fontSize: 12, fontWeight: 600 }}>✅ Complet</span>
              return <span style={{ background: COLORS.tealSoft, color: COLORS.teal, padding: '6px 14px', borderRadius: 100, fontSize: 12, fontWeight: 700 }}>🎾 {spots} place{spots > 1 ? 's' : ''}</span>
            })()}
          </div>

          {/* Demandes en attente */}
          {isOrganizer() && pendingRequests.length > 0 && (
            <div style={{ background: COLORS.amberSoft, border: `2px solid ${COLORS.amber}40`, borderRadius: 20, padding: 18, marginBottom: 18 }}>
              <div style={{ fontWeight: 700, color: COLORS.amberDark, marginBottom: 14 }}>📬 Demandes en attente ({pendingRequests.length})</div>
              {pendingRequests.map((req, i) => (
                <div key={req.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 12, background: COLORS.white, borderRadius: 14, marginBottom: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <Avatar name={req.profiles?.name} size={40} avatarUrl={req.profiles?.avatar_url} index={i} />
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.ink }}>{req.profiles?.name}</div>
                      <div style={{ fontSize: 12, color: COLORS.gray }}>Niveau {req.profiles?.level} · Équipe {req.team}</div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => acceptRequest(req)} style={{ padding: '8px 16px', background: COLORS.teal, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>✓</button>
                    <button onClick={() => refuseRequest(req)} style={{ padding: '8px 14px', background: COLORS.bgSoft, color: COLORS.gray, border: 'none', borderRadius: 100, fontSize: 12, cursor: 'pointer' }}>✕</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Carte Terrain Junto */}
          <div style={{ background: COLORS.white, borderRadius: 24, overflow: 'hidden', border: `2px solid ${COLORS.border}`, boxShadow: '0 4px 24px rgba(0,0,0,0.06)', marginBottom: 20 }}>
            
            {/* Header date/heure/lieu */}
            <div style={{ background: COLORS.ink, padding: '22px', color: COLORS.white }}>
              <div className="match-header">
                <div style={{ textAlign: 'center', flex: 1 }}>
                  <div style={{ fontSize: 12, opacity: 0.6, marginBottom: 4 }}>📅</div>
                  <div style={{ fontSize: 16, fontWeight: 700 }}>{formatDateShort(match.match_date)}</div>
                </div>
                <div style={{ textAlign: 'center', flex: 1 }}>
                  <div style={{ fontSize: 40, fontWeight: 800, lineHeight: 1 }}>{formatTime(match.match_time)}</div>
                </div>
                <div style={{ textAlign: 'center', flex: 1 }}>
                  <div style={{ fontSize: 12, opacity: 0.6, marginBottom: 4 }}>📍</div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{match.clubs?.name || match.city || 'Lieu TBD'}</div>
                </div>
              </div>
            </div>

            {/* Terrain Junto */}
            <div style={{ background: `linear-gradient(180deg, ${COLORS.secondary} 0%, ${COLORS.ink} 100%)`, padding: '24px 16px', position: 'relative' }}>
              {/* Logo Junto */}
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 20 }}>
                <div style={{ background: 'rgba(0,0,0,0.4)', padding: '10px 24px', borderRadius: 100, display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ color: COLORS.white, fontSize: 14, fontWeight: 700 }}>junto</span>
                  <div style={{ display: 'flex', gap: 4 }}>{FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: c }} />)}</div>
                </div>
              </div>

              {/* Terrain container */}
              <div style={{ position: 'relative', border: '2px solid rgba(255,255,255,0.25)', borderRadius: 12, padding: '24px 14px' }}>
                {/* Ligne filet */}
                <div style={{ position: 'absolute', left: '50%', top: 20, bottom: 20, width: 2, background: 'rgba(255,255,255,0.3)', transform: 'translateX(-50%)' }} />
                
                {/* Équipes */}
                <div style={{ display: 'flex', justifyContent: 'space-around' }}>
                  {/* Équipe A */}
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 11, color: COLORS.primary, fontWeight: 700, marginBottom: 12, background: `${COLORS.primary}30`, padding: '4px 12px', borderRadius: 100, display: 'inline-block' }}>ÉQUIPE A</div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                      {[0, 1].map(i => <PlayerCard key={i} player={teamA[i]} index={i} onClickPlayer={p => setSelectedPlayer(p)} onClickEmpty={isOrganizer() ? () => router.push(`/dashboard/joueurs?match=${matchId}`) : null} />)}
                    </div>
                  </div>
                  {/* Équipe B */}
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 11, color: COLORS.amber, fontWeight: 700, marginBottom: 12, background: `${COLORS.amber}30`, padding: '4px 12px', borderRadius: 100, display: 'inline-block' }}>ÉQUIPE B</div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                      {[0, 1].map(i => <PlayerCard key={i} player={teamB[i]} index={i + 2} onClickPlayer={p => setSelectedPlayer(p)} onClickEmpty={isOrganizer() ? () => router.push(`/dashboard/joueurs?match=${matchId}`) : null} />)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Infos match */}
              <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginTop: 20 }}>
                <span style={{ background: 'rgba(255,255,255,0.1)', padding: '8px 16px', borderRadius: 100, fontSize: 13, color: 'rgba(255,255,255,0.9)' }}>⭐ Niv. {match.level_min}-{match.level_max}</span>
                <span style={{ background: `${ambiance.color}30`, padding: '8px 16px', borderRadius: 100, fontSize: 13, color: ambiance.color }}>{ambiance.emoji} {ambiance.label}</span>
                {pricePerPerson > 0 && <span style={{ background: 'rgba(255,255,255,0.1)', padding: '8px 16px', borderRadius: 100, fontSize: 13, color: 'rgba(255,255,255,0.9)' }}>💰 {pricePerPerson}€/pers</span>}
              </div>
            </div>
          </div>

          {/* Bouton Rejoindre */}
          {canJoin && (
            <button onClick={() => setModal('join')} style={{ width: '100%', padding: 18, background: COLORS.primary, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 16, fontWeight: 700, cursor: 'pointer', marginBottom: 20, fontFamily: "'Satoshi', sans-serif", boxShadow: `0 4px 20px ${COLORS.primaryGlow}` }}>
              🎾 Rejoindre cette partie
            </button>
          )}

          {/* Chat */}
          {(isOrganizer() || isParticipant()) && (
            <div style={{ background: COLORS.white, borderRadius: 24, padding: 22, border: `2px solid ${COLORS.border}`, marginBottom: 20 }}>
              <h3 style={{ fontSize: 17, fontWeight: 700, margin: '0 0 18px', color: COLORS.ink }}>💬 Discussion</h3>
              <div style={{ maxHeight: 300, overflowY: 'auto', marginBottom: 16 }}>
                {messages.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: 24, color: COLORS.muted, fontSize: 14 }}>Aucun message. Lancez la conversation !</div>
                ) : messages.map((msg, i) => (
                  <div key={msg.id} style={{ display: 'flex', gap: 12, marginBottom: 14 }}>
                    <Avatar name={msg.profiles?.name} size={36} avatarUrl={msg.profiles?.avatar_url} index={i} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: COLORS.ink }}>{msg.profiles?.name} <span style={{ fontWeight: 400, color: COLORS.muted, fontSize: 11 }}>{new Date(msg.created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</span></div>
                      <div style={{ fontSize: 14, color: COLORS.dark, marginTop: 4 }}>{msg.message}</div>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
              <form onSubmit={sendMessage} style={{ display: 'flex', gap: 10 }}>
                <input value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Écrire un message..." style={{ flex: 1, padding: '14px 18px', border: `2px solid ${COLORS.border}`, borderRadius: 100, fontSize: 14, fontFamily: "'Satoshi', sans-serif" }} />
                <button type="submit" style={{ padding: '14px 24px', background: COLORS.primary, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>Envoyer</button>
              </form>
            </div>
          )}

          {/* Actions */}
          {(isOrganizer() || isParticipant()) && (
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              {isOrganizer() && <Link href={`/dashboard/matches/create?edit=${matchId}`} style={{ flex: 1, padding: 14, background: COLORS.bgSoft, color: COLORS.ink, border: `2px solid ${COLORS.border}`, borderRadius: 100, fontSize: 14, fontWeight: 600, textDecoration: 'none', textAlign: 'center' }}>✏️ Modifier</Link>}
              {isOrganizer() && <button onClick={() => setModal('cancel')} style={{ flex: 1, padding: 14, background: COLORS.primarySoft, color: COLORS.primary, border: 'none', borderRadius: 100, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>❌ Annuler</button>}
              {isParticipant() && !isOrganizer() && <button onClick={() => setModal('leave')} style={{ flex: 1, padding: 14, background: COLORS.primarySoft, color: COLORS.primary, border: 'none', borderRadius: 100, fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>Quitter</button>}
            </div>
          )}
        </div>
      </div>

      {/* Modal Rejoindre */}
      {modal === 'join' && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }} onClick={() => setModal(null)}>
          <div onClick={e => e.stopPropagation()} style={{ background: COLORS.white, borderRadius: 28, padding: 28, width: '100%', maxWidth: 380 }}>
            <h3 style={{ fontSize: 22, fontWeight: 700, margin: '0 0 20px', color: COLORS.ink, textAlign: 'center' }}>🎾 Rejoindre la partie</h3>
            <p style={{ fontSize: 14, color: COLORS.gray, marginBottom: 20, textAlign: 'center' }}>Choisis ton équipe</p>
            <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
              {['A', 'B'].map(team => (
                <button key={team} onClick={() => setJoinTeam(team)} style={{ flex: 1, padding: 18, background: joinTeam === team ? (team === 'A' ? COLORS.primary : COLORS.amber) : COLORS.bgSoft, color: joinTeam === team ? COLORS.white : COLORS.gray, border: `2px solid ${joinTeam === team ? (team === 'A' ? COLORS.primary : COLORS.amber) : COLORS.border}`, borderRadius: 16, fontSize: 16, fontWeight: 700, cursor: 'pointer' }}>Équipe {team}</button>
              ))}
            </div>
            <button onClick={requestToJoin} style={{ width: '100%', padding: 18, background: COLORS.teal, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 16, fontWeight: 700, cursor: 'pointer', fontFamily: "'Satoshi', sans-serif" }}>Envoyer ma demande</button>
            <button onClick={() => setModal(null)} style={{ width: '100%', marginTop: 12, background: 'none', border: 'none', color: COLORS.muted, fontSize: 14, cursor: 'pointer' }}>Annuler</button>
          </div>
        </div>
      )}

      {/* Modal Annuler */}
      {modal === 'cancel' && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }} onClick={() => setModal(null)}>
          <div onClick={e => e.stopPropagation()} style={{ background: COLORS.white, borderRadius: 28, padding: 28, width: '100%', maxWidth: 380, textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>⚠️</div>
            <h3 style={{ fontSize: 20, fontWeight: 700, margin: '0 0 12px', color: COLORS.ink }}>Annuler cette partie ?</h3>
            <p style={{ fontSize: 14, color: COLORS.gray, marginBottom: 24 }}>Les participants seront notifiés de l'annulation.</p>
            <button onClick={cancelMatch} style={{ width: '100%', padding: 16, background: COLORS.primary, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 15, fontWeight: 700, cursor: 'pointer', marginBottom: 12 }}>Oui, annuler</button>
            <button onClick={() => setModal(null)} style={{ width: '100%', padding: 14, background: COLORS.bgSoft, color: COLORS.gray, border: 'none', borderRadius: 100, fontSize: 14, cursor: 'pointer' }}>Non, garder</button>
          </div>
        </div>
      )}

      {/* Modal Quitter */}
      {modal === 'leave' && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }} onClick={() => setModal(null)}>
          <div onClick={e => e.stopPropagation()} style={{ background: COLORS.white, borderRadius: 28, padding: 28, width: '100%', maxWidth: 380, textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>👋</div>
            <h3 style={{ fontSize: 20, fontWeight: 700, margin: '0 0 12px', color: COLORS.ink }}>Quitter cette partie ?</h3>
            <p style={{ fontSize: 14, color: COLORS.gray, marginBottom: 24 }}>Ta place sera libérée pour un autre joueur.</p>
            <button onClick={leaveMatch} style={{ width: '100%', padding: 16, background: COLORS.primary, color: COLORS.white, border: 'none', borderRadius: 100, fontSize: 15, fontWeight: 700, cursor: 'pointer', marginBottom: 12 }}>Oui, quitter</button>
            <button onClick={() => setModal(null)} style={{ width: '100%', padding: 14, background: COLORS.bgSoft, color: COLORS.gray, border: 'none', borderRadius: 100, fontSize: 14, cursor: 'pointer' }}>Non, rester</button>
          </div>
        </div>
      )}

      {/* Modal Profil Joueur */}
      {selectedPlayer && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }} onClick={() => setSelectedPlayer(null)}>
          <div onClick={e => e.stopPropagation()} style={{ background: COLORS.white, borderRadius: 28, padding: 28, width: '100%', maxWidth: 340, textAlign: 'center' }}>
            <Avatar name={selectedPlayer.name} size={80} avatarUrl={selectedPlayer.avatar_url} index={0} />
            <h3 style={{ fontSize: 20, fontWeight: 700, margin: '16px 0 8px', color: COLORS.ink }}>{selectedPlayer.name}</h3>
            <div style={{ fontSize: 14, color: COLORS.gray, marginBottom: 20 }}>⭐ Niveau {selectedPlayer.level || '?'}</div>
            <Link href={`/player/${selectedPlayer.id}`} style={{ display: 'block', padding: 16, background: COLORS.primary, color: COLORS.white, borderRadius: 100, fontSize: 15, fontWeight: 700, textDecoration: 'none', marginBottom: 12 }}>Voir le profil</Link>
            <button onClick={() => setSelectedPlayer(null)} style={{ width: '100%', padding: 14, background: COLORS.bgSoft, color: COLORS.gray, border: 'none', borderRadius: 100, fontSize: 14, cursor: 'pointer' }}>Fermer</button>
          </div>
        </div>
      )}

      <style jsx global>{`
        @keyframes junto-loading { 0%, 80%, 100% { transform: translateY(0); } 40% { transform: translateY(-12px); } }
        .junto-loading-dot { animation: junto-loading 1.4s ease-in-out infinite; }
        .junto-loading-dot:nth-child(1) { animation-delay: 0s; }
        .junto-loading-dot:nth-child(2) { animation-delay: 0.1s; }
        .junto-loading-dot:nth-child(3) { animation-delay: 0.2s; }
        .junto-loading-dot:nth-child(4) { animation-delay: 0.3s; }
        .page-container { max-width: 900px; margin: 0 auto; }
        .main-column { width: 100%; }
        .match-header { display: flex; align-items: center; }
        input:focus { border-color: ${COLORS.primary} !important; outline: none; }
      `}</style>
    </div>
  )
}
