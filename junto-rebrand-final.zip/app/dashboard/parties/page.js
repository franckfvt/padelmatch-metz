'use client'

/**
 * ============================================
 * PAGE PARTIES - JUNTO BRAND
 * ============================================
 * 
 * LOGIQUE 100% IDENTIQUE - SEULS LES STYLES CHANGENT
 * 
 * Structure préservée:
 * - Greeting "Bonjour X"
 * - Hero "Organise une partie" 
 * - Tes prochaines parties
 * - Parties à rejoindre
 * - Sidebar
 * 
 * ============================================
 */

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { COLORS, FOUR_DOTS, getAvatarColor, AMBIANCE_CONFIG } from '@/app/lib/design-tokens'

export default function PartiesPage() {
  const router = useRouter()
  
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  
  const [showAllMatches, setShowAllMatches] = useState(false)
  const [filterDate, setFilterDate] = useState('week')
  const [filterCity, setFilterCity] = useState('all')
  const [cities, setCities] = useState([])
  
  const [availableMatches, setAvailableMatches] = useState([])
  const [myUpcomingMatches, setMyUpcomingMatches] = useState([])
  
  const [pendingActions, setPendingActions] = useState({
    invitesForMe: [],
    requestsToReview: [],
    invitesToFollow: []
  })
  
  const [stats, setStats] = useState({ total: 0, organized: 0, wins: 0 })
  const [favoritePlayers, setFavoritePlayers] = useState([])

  useEffect(() => { loadData() }, [])

  // === LOGIQUE IDENTIQUE ===
  async function loadData() {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) { router.push('/auth'); return }

    setUser(session.user)
    const userId = session.user.id
    const today = new Date().toISOString().split('T')[0]

    const [profileResult, availableResult, orgMatchesResult, partMatchesResult] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', userId).single(),
      supabase.from('matches')
        .select(`*, clubs (id, name, city), profiles!matches_organizer_id_fkey (id, name, avatar_url), match_participants (id, user_id, status, profiles!match_participants_user_id_fkey (id, name, avatar_url))`)
        .eq('status', 'open').gt('spots_available', 0).gte('match_date', today).neq('organizer_id', userId)
        .order('match_date', { ascending: true }).limit(20),
      supabase.from('matches')
        .select(`*, clubs (name, city), profiles!matches_organizer_id_fkey (id, name, avatar_url), match_participants (id, user_id, team, status, profiles!match_participants_user_id_fkey (id, name, avatar_url))`)
        .eq('organizer_id', userId).gte('match_date', today).order('match_date', { ascending: true }),
      supabase.from('match_participants')
        .select(`match_id, status, matches!inner (*, clubs (name, city), profiles!matches_organizer_id_fkey (id, name, avatar_url), match_participants (id, user_id, team, status, profiles!match_participants_user_id_fkey (id, name, avatar_url)))`)
        .eq('user_id', userId).eq('status', 'confirmed').gte('matches.match_date', today)
    ])

    const profileData = profileResult.data
    setProfile(profileData)

    const filteredAvailable = (availableResult.data || []).filter(m => 
      !m.match_participants?.some(p => p.user_id === userId)
    )
    setAvailableMatches(filteredAvailable)

    const citiesSet = new Set()
    filteredAvailable.forEach(m => { 
      if (m.clubs?.city) citiesSet.add(m.clubs.city)
      if (m.city) citiesSet.add(m.city) 
    })
    setCities(Array.from(citiesSet).sort())
    if (profileData?.city) setFilterCity(profileData.city)

    const allUpcoming = [...(orgMatchesResult.data || [])]
    const orgIds = new Set(allUpcoming.map(m => m.id))
    ;(partMatchesResult.data || []).forEach(p => { 
      if (p.matches && !orgIds.has(p.matches.id)) {
        allUpcoming.push({ ...p.matches, _isParticipant: true }) 
      }
    })
    allUpcoming.sort((a, b) => {
      const dateA = new Date(`${a.match_date}T${a.match_time || '00:00'}`)
      const dateB = new Date(`${b.match_date}T${b.match_time || '00:00'}`)
      return dateA - dateB
    })
    setMyUpcomingMatches(allUpcoming)
    
    await loadPendingActions(userId, orgMatchesResult.data || [])
    
    setLoading(false)
    loadSidebarData(userId, today)
  }

  async function loadPendingActions(userId, myMatches) {
    const matchIds = myMatches.map(m => m.id)
    if (matchIds.length === 0) {
      setPendingActions({ invitesForMe: [], requestsToReview: [], invitesToFollow: [] })
      return
    }

    const { data: pendingRequests } = await supabase
      .from('match_participants')
      .select(`*, matches!inner (id, match_date, match_time, clubs (name)), profiles!match_participants_user_id_fkey (id, name, avatar_url, level)`)
      .in('match_id', matchIds)
      .eq('status', 'pending')

    const { data: pendingInvites } = await supabase
      .from('pending_invites')
      .select(`*, matches!inner (id, match_date, match_time, clubs (name))`)
      .in('match_id', matchIds)
      .eq('status', 'pending')

    const invitesWithAge = (pendingInvites || []).map(inv => {
      const created = new Date(inv.created_at)
      const now = new Date()
      const hoursSince = Math.floor((now - created) / (1000 * 60 * 60))
      const daysSince = Math.floor(hoursSince / 24)
      return { ...inv, hoursSince, daysSince }
    })

    setPendingActions({
      invitesForMe: [],
      requestsToReview: pendingRequests || [],
      invitesToFollow: invitesWithAge
    })
  }

  async function loadSidebarData(userId, today) {
    const [pastResult, organizedCount, favoritesResult] = await Promise.all([
      supabase.from('match_participants')
        .select(`match_id, matches!inner (id, match_date, winner)`)
        .eq('user_id', userId).lt('matches.match_date', today).limit(100),
      supabase.from('matches')
        .select('id', { count: 'exact', head: true })
        .eq('organizer_id', userId),
      supabase.from('player_favorites')
        .select(`profiles!player_favorites_favorite_user_id_fkey (id, name, avatar_url, level, city)`)
        .eq('user_id', userId).limit(5)
    ])
    
    const uniquePast = new Set((pastResult.data || []).map(p => p.match_id))
    const wins = (pastResult.data || []).filter(p => p.matches?.winner).length
    setStats({ total: uniquePast.size, organized: organizedCount.count || 0, wins })
    setFavoritePlayers((favoritesResult.data || []).map(f => f.profiles).filter(Boolean))
  }

  // === HELPERS ===
  function getGreeting() {
    const hour = new Date().getHours()
    const firstName = profile?.name?.split(' ')[0] || ''
    if (hour < 12) return `Bonjour ${firstName} 👋`
    if (hour < 18) return `Salut ${firstName} 👋`
    return `Bonsoir ${firstName} 👋`
  }

  function formatDate(dateStr) {
    if (!dateStr) return 'Flexible'
    const date = new Date(dateStr)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    if (date.toDateString() === today.toDateString()) return "Aujourd'hui"
    if (date.toDateString() === tomorrow.toDateString()) return 'Demain'
    return date.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric' })
  }

  function formatTime(timeStr) { return timeStr ? timeStr.slice(0, 5) : 'Flexible' }
  function getMatchLocation(match) { return match.clubs?.name || match.city || 'Lieu à définir' }

  function getMatchPlayers(match) {
    const players = []
    if (match.profiles) {
      players.push({ id: match.organizer_id, name: match.profiles.name, avatar_url: match.profiles.avatar_url })
    }
    ;(match.match_participants || []).forEach(p => { 
      if (p.user_id !== match.organizer_id && p.profiles && p.status === 'confirmed') {
        players.push({ id: p.user_id, name: p.profiles.name, avatar_url: p.profiles.avatar_url }) 
      }
    })
    return players
  }

  async function acceptRequest(req) {
    await supabase.from('match_participants').update({ status: 'confirmed' }).eq('id', req.id)
    loadData()
  }

  async function refuseRequest(req) {
    await supabase.from('match_participants').delete().eq('id', req.id)
    loadData()
  }

  async function cancelInvite(invite) {
    await supabase.from('pending_invites').delete().eq('id', invite.id)
    loadData()
  }

  function getTotalPendingActions() {
    return pendingActions.requestsToReview.length + pendingActions.invitesToFollow.filter(i => i.daysSince >= 2).length
  }

  // Filtres
  const filteredAvailable = availableMatches.filter(match => {
    if (filterCity !== 'all') {
      const matchCity = (match.clubs?.city || match.city || '').toLowerCase()
      if (matchCity !== filterCity.toLowerCase()) return false
    }
    if (match.match_date) {
      const matchDate = new Date(match.match_date)
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      const tomorrow = new Date(today)
      tomorrow.setDate(tomorrow.getDate() + 1)
      const endOfWeek = new Date(today)
      endOfWeek.setDate(endOfWeek.getDate() + 7)
      
      if (filterDate === 'today' && matchDate.toDateString() !== today.toDateString()) return false
      if (filterDate === 'tomorrow' && matchDate.toDateString() !== tomorrow.toDateString()) return false
      if (filterDate === 'week' && matchDate > endOfWeek) return false
      if (filterDate === 'weekend') {
        const day = matchDate.getDay()
        if (day !== 0 && day !== 6) return false
      }
    }
    return true
  })

  const visibleMatches = myUpcomingMatches.slice(0, 3)
  const hiddenMatches = myUpcomingMatches.slice(3)

  // === COMPOSANTS JUNTO ===
  function Avatar({ player, size = 32, overlap = false, index = 0 }) {
    const playerColor = FOUR_DOTS.colors[index % 4]
    
    if (!player) {
      return (
        <div style={{
          width: size, height: size, borderRadius: '50%',
          background: COLORS.bgSoft, border: `2px dashed ${COLORS.border}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: size * 0.4, color: COLORS.muted,
          marginLeft: overlap && index > 0 ? -10 : 0,
          position: 'relative', zIndex: 4 - index,
          flexShrink: 0
        }}>?</div>
      )
    }
    
    return (
      <div className="avatar-hover" style={{
        width: size, height: size, borderRadius: '50%',
        background: player.avatar_url ? COLORS.bgSoft : playerColor,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: size * 0.4, fontWeight: 700, color: COLORS.white,
        overflow: 'hidden',
        border: `3px solid ${COLORS.white}`,
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        marginLeft: overlap && index > 0 ? -10 : 0,
        position: 'relative', zIndex: 4 - index,
        flexShrink: 0
      }}>
        {player.avatar_url 
          ? <img src={player.avatar_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : player.name?.[0]?.toUpperCase()
        }
      </div>
    )
  }

  // === LOADING ===
  if (loading) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: 16 }}>
        <div style={{ display: 'flex', gap: 8 }}>
          {FOUR_DOTS.colors.map((color, i) => (
            <div key={i} className="junto-loading-dot" style={{ width: 14, height: 14, borderRadius: '50%', background: color }} />
          ))}
        </div>
        <div style={{ color: COLORS.gray, fontSize: 15 }}>Chargement...</div>
      </div>
    )
  }

  // === RENDER ===
  return (
    <>
      <div className="page-container">
        
        <div className="main-column">
          
          {/* Greeting */}
          <h1 style={{ fontSize: 26, fontWeight: 700, margin: '0 0 20px', color: COLORS.ink, letterSpacing: -0.5 }}>
            {getGreeting()}
          </h1>

          {/* HERO - Organise une partie */}
          <div className="hero-card" style={{ 
            background: COLORS.ink, 
            borderRadius: 20, 
            padding: '24px',
            marginBottom: 20,
            position: 'relative',
            overflow: 'hidden'
          }}>
            {/* Decoration dots */}
            <div style={{ position: 'absolute', top: 16, right: 16, display: 'flex', gap: 6, opacity: 0.3 }}>
              {FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: c }} />)}
            </div>
            
            <div className="hero-content">
              <div>
                <h2 style={{ fontSize: 20, fontWeight: 700, color: COLORS.white, margin: '0 0 6px' }}>
                  Organise une partie
                </h2>
                <p style={{ fontSize: 14, color: COLORS.muted, margin: 0 }}>
                  Invite tes partenaires à jouer
                </p>
              </div>
              <Link href="/dashboard/matches/create" className="create-btn" style={{ 
                padding: '14px 28px', 
                background: COLORS.primary, 
                color: COLORS.white, 
                border: 'none', 
                borderRadius: 100, 
                fontSize: 15, 
                fontWeight: 700, 
                cursor: 'pointer',
                textDecoration: 'none',
                display: 'inline-flex',
                alignItems: 'center',
                gap: 8,
                boxShadow: `0 4px 16px ${COLORS.primaryGlow}`,
                whiteSpace: 'nowrap',
                fontFamily: "'Satoshi', sans-serif"
              }}>
                + Créer une partie
              </Link>
            </div>
          </div>

          {/* MES PROCHAINES PARTIES */}
          {myUpcomingMatches.length > 0 && (
            <div style={{ 
              background: COLORS.white, 
              borderRadius: 20, 
              padding: 22,
              border: `2px solid ${COLORS.border}`,
              marginBottom: 20
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
                <h2 style={{ fontSize: 17, fontWeight: 700, margin: 0, color: COLORS.ink, display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span>🗓️</span> Tes prochaines parties
                </h2>
                <span style={{ fontSize: 13, color: COLORS.gray, fontWeight: 500 }}>
                  {myUpcomingMatches.length} partie{myUpcomingMatches.length > 1 ? 's' : ''}
                </span>
              </div>

              <div className="matches-grid">
                {visibleMatches.map((match, matchIndex) => {
                  const isOrganizer = match.organizer_id === user?.id
                  const players = getMatchPlayers(match)
                  const allSlots = [...players]
                  while (allSlots.length < 4) allSlots.push(null)
                  
                  return (
                    <Link href={`/dashboard/match/${match.id}`} key={match.id} style={{ textDecoration: 'none' }}>
                      <div className="match-card" style={{ 
                        background: COLORS.bgSoft, 
                        borderRadius: 16, 
                        padding: 18,
                        border: `2px solid transparent`,
                        cursor: 'pointer',
                        transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
                        height: '100%',
                        position: 'relative',
                        overflow: 'hidden'
                      }}>
                        {/* Accent bar */}
                        <div style={{
                          position: 'absolute',
                          top: 0,
                          left: 0,
                          right: 0,
                          height: 4,
                          background: `linear-gradient(90deg, ${COLORS.primary}, ${COLORS.amber})`
                        }} />
                        
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12, marginTop: 4 }}>
                          <div>
                            <div style={{ fontSize: 12, color: COLORS.gray, fontWeight: 500 }}>{formatDate(match.match_date)}</div>
                            <div style={{ fontSize: 26, fontWeight: 700, color: COLORS.ink }}>{formatTime(match.match_time)}</div>
                          </div>
                          {isOrganizer && (
                            <span style={{ 
                              background: COLORS.amberSoft, 
                              color: COLORS.amberDark, 
                              padding: '4px 10px', 
                              borderRadius: 8, 
                              fontSize: 11, 
                              fontWeight: 700,
                              height: 'fit-content'
                            }}>👑 Orga</span>
                          )}
                        </div>
                        <div style={{ fontSize: 13, color: COLORS.gray, marginBottom: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
                          <span>📍</span> {getMatchLocation(match)}
                        </div>
                        <div style={{ display: 'flex', gap: 6 }}>
                          {allSlots.map((player, idx) => (
                            <Avatar key={idx} player={player} size={32} index={idx} />
                          ))}
                        </div>
                      </div>
                    </Link>
                  )
                })}
              </div>

              {/* Parties supplémentaires */}
              {showAllMatches && hiddenMatches.length > 0 && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 14, marginTop: 14, borderTop: `1px solid ${COLORS.border}` }}>
                  {hiddenMatches.map((match) => {
                    const isOrganizer = match.organizer_id === user?.id
                    const players = getMatchPlayers(match)
                    const allSlots = [...players]
                    while (allSlots.length < 4) allSlots.push(null)
                    
                    return (
                      <Link href={`/dashboard/match/${match.id}`} key={match.id} style={{ textDecoration: 'none' }}>
                        <div style={{ 
                          display: 'flex', alignItems: 'center', gap: 14,
                          padding: '12px 16px',
                          background: COLORS.bgSoft,
                          borderRadius: 12,
                          cursor: 'pointer',
                          transition: 'all 0.2s'
                        }}>
                          <div style={{ minWidth: 70 }}>
                            <div style={{ fontSize: 11, color: COLORS.gray }}>{formatDate(match.match_date)}</div>
                            <div style={{ fontSize: 18, fontWeight: 700, color: COLORS.ink }}>{formatTime(match.match_time)}</div>
                          </div>
                          <div style={{ flex: 1, fontSize: 13, color: COLORS.dark, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            📍 {getMatchLocation(match)}
                          </div>
                          {isOrganizer && (
                            <span style={{ background: COLORS.amberSoft, color: COLORS.amberDark, padding: '3px 8px', borderRadius: 6, fontSize: 10, fontWeight: 700 }}>👑</span>
                          )}
                          <div style={{ display: 'flex' }}>
                            {allSlots.map((player, idx) => <Avatar key={idx} player={player} size={26} overlap index={idx} />)}
                          </div>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              )}

              {myUpcomingMatches.length > 3 && (
                <button onClick={() => setShowAllMatches(!showAllMatches)} style={{ 
                  width: '100%', marginTop: 14, padding: '12px',
                  background: 'transparent', border: `2px solid ${COLORS.border}`,
                  borderRadius: 12, fontSize: 13, fontWeight: 600, color: COLORS.gray,
                  cursor: 'pointer', fontFamily: "'Satoshi', sans-serif"
                }}>
                  {showAllMatches ? '← Voir moins' : `Voir ${hiddenMatches.length} autre${hiddenMatches.length > 1 ? 's' : ''} →`}
                </button>
              )}
            </div>
          )}

          {/* CENTRE D'ACTIONS */}
          {(pendingActions.requestsToReview.length > 0 || pendingActions.invitesToFollow.length > 0) && (
            <div style={{ 
              background: COLORS.white, 
              borderRadius: 20, 
              padding: 22,
              border: `2px solid ${COLORS.amber}`,
              marginBottom: 20
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: COLORS.amber }} className="junto-dot" />
                <h2 style={{ fontSize: 17, fontWeight: 700, margin: 0, color: COLORS.ink }}>
                  Actions en attente
                </h2>
                <span style={{ 
                  background: COLORS.primary, color: COLORS.white,
                  padding: '3px 10px', borderRadius: 100, fontSize: 12, fontWeight: 700
                }}>{getTotalPendingActions()}</span>
              </div>

              {/* Demandes à valider */}
              {pendingActions.requestsToReview.length > 0 && (
                <div style={{ marginBottom: 16 }}>
                  <h4 style={{ fontSize: 13, color: COLORS.gray, margin: '0 0 10px', fontWeight: 600 }}>
                    Demandes à valider ({pendingActions.requestsToReview.length})
                  </h4>
                  {pendingActions.requestsToReview.map(req => (
                    <div key={req.id} style={{ 
                      background: COLORS.bgSoft, borderRadius: 14, padding: 14,
                      display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8
                    }}>
                      <Avatar player={req.profiles} size={44} index={0} />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, color: COLORS.ink, fontSize: 14 }}>{req.profiles?.name}</div>
                        <div style={{ fontSize: 12, color: COLORS.gray }}>Niveau {req.profiles?.level} · {formatDate(req.matches?.match_date)}</div>
                      </div>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <button onClick={() => refuseRequest(req)} style={{
                          padding: '8px 14px', background: COLORS.bgSoft, border: `1px solid ${COLORS.border}`,
                          borderRadius: 10, fontSize: 13, cursor: 'pointer', color: COLORS.gray
                        }}>✕</button>
                        <button onClick={() => acceptRequest(req)} style={{
                          padding: '8px 16px', background: COLORS.teal, border: 'none',
                          borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: 'pointer', color: COLORS.white
                        }}>✓ Accepter</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Invités à relancer */}
              {pendingActions.invitesToFollow.filter(i => i.daysSince >= 2).length > 0 && (
                <div>
                  <h4 style={{ fontSize: 13, color: COLORS.gray, margin: '0 0 10px', fontWeight: 600 }}>
                    À relancer
                  </h4>
                  {pendingActions.invitesToFollow.filter(i => i.daysSince >= 2).map(inv => (
                    <div key={inv.id} style={{ 
                      background: COLORS.amberSoft, borderRadius: 14, padding: 14,
                      display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8
                    }}>
                      <div style={{ fontSize: 24 }}>⏳</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, color: COLORS.ink, fontSize: 14 }}>{inv.name || inv.phone}</div>
                        <div style={{ fontSize: 12, color: COLORS.amberDark }}>Invité il y a {inv.daysSince} jours</div>
                      </div>
                      <button onClick={() => cancelInvite(inv)} style={{
                        padding: '8px 14px', background: COLORS.white, border: `1px solid ${COLORS.border}`,
                        borderRadius: 10, fontSize: 12, cursor: 'pointer', color: COLORS.gray
                      }}>Annuler</button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* PARTIES À REJOINDRE */}
          <div style={{ 
            background: COLORS.white, 
            borderRadius: 20, 
            padding: 22,
            border: `2px solid ${COLORS.border}`,
            marginBottom: 20
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h2 style={{ fontSize: 17, fontWeight: 700, margin: 0, color: COLORS.ink, display: 'flex', alignItems: 'center', gap: 8 }}>
                <span>🔥</span> Parties à rejoindre
              </h2>
              <span style={{ fontSize: 13, color: COLORS.gray, fontWeight: 500 }}>
                {filteredAvailable.length} disponible{filteredAvailable.length > 1 ? 's' : ''}
              </span>
            </div>

            {/* Filtres */}
            <div className="filters-row" style={{ display: 'flex', gap: 8, marginBottom: 18, overflowX: 'auto', paddingBottom: 4 }}>
              {cities.length > 0 && (
                <select value={filterCity} onChange={(e) => setFilterCity(e.target.value)} style={{
                  padding: '10px 16px', fontSize: 13,
                  border: `2px solid ${filterCity !== 'all' ? COLORS.primary : COLORS.border}`,
                  borderRadius: 100,
                  background: filterCity !== 'all' ? COLORS.primarySoft : COLORS.white,
                  color: filterCity !== 'all' ? COLORS.primary : COLORS.gray,
                  cursor: 'pointer', fontWeight: 600, whiteSpace: 'nowrap', flexShrink: 0,
                  fontFamily: "'Satoshi', sans-serif"
                }}>
                  <option value="all">📍 Toutes villes</option>
                  {cities.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              )}

              {[
                { id: 'week', label: 'Cette semaine' },
                { id: 'today', label: "Aujourd'hui" },
                { id: 'tomorrow', label: 'Demain' },
                { id: 'weekend', label: 'Week-end' }
              ].map(f => (
                <button key={f.id} onClick={() => setFilterDate(f.id)} style={{
                  padding: '10px 16px',
                  background: filterDate === f.id ? COLORS.ink : COLORS.white,
                  color: filterDate === f.id ? COLORS.white : COLORS.gray,
                  border: `2px solid ${filterDate === f.id ? COLORS.ink : COLORS.border}`,
                  borderRadius: 100, fontSize: 13, fontWeight: 600, cursor: 'pointer',
                  whiteSpace: 'nowrap', flexShrink: 0, fontFamily: "'Satoshi', sans-serif"
                }}>{f.label}</button>
              ))}
            </div>

            {/* Liste des parties */}
            {filteredAvailable.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px 20px', background: COLORS.bgSoft, borderRadius: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginBottom: 16, opacity: 0.4 }}>
                  {FOUR_DOTS.colors.map((c, i) => <div key={i} style={{ width: 10, height: 10, borderRadius: '50%', background: c }} />)}
                </div>
                <h4 style={{ fontSize: 16, fontWeight: 600, color: COLORS.gray, marginBottom: 6 }}>Aucune partie trouvée</h4>
                <p style={{ fontSize: 14, color: COLORS.muted, margin: 0 }}>Essaie d'élargir tes filtres</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {filteredAvailable.map((match, matchIndex) => {
                  const players = getMatchPlayers(match)
                  const allSlots = [...players]
                  while (allSlots.length < 4) allSlots.push(null)
                  const spotsLeft = 4 - players.length
                  const ambiance = AMBIANCE_CONFIG[match.ambiance] || AMBIANCE_CONFIG.mix
                  
                  return (
                    <Link href={`/join/${match.id}`} key={match.id} style={{ textDecoration: 'none' }}>
                      <div className="available-card" style={{ 
                        background: COLORS.white, 
                        borderRadius: 16, 
                        padding: 16,
                        border: `2px solid ${COLORS.border}`,
                        display: 'flex',
                        gap: 16,
                        alignItems: 'center',
                        cursor: 'pointer',
                        transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)'
                      }}>
                        {/* Badge Date/Heure */}
                        <div style={{ 
                          background: COLORS.ink, 
                          borderRadius: 14, 
                          padding: '14px 16px',
                          color: COLORS.white,
                          textAlign: 'center',
                          minWidth: 75,
                          flexShrink: 0
                        }}>
                          <div style={{ fontSize: 11, opacity: 0.7, fontWeight: 500 }}>{formatDate(match.match_date)}</div>
                          <div style={{ fontSize: 20, fontWeight: 700 }}>{formatTime(match.match_time)}</div>
                        </div>

                        {/* Infos */}
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 600, fontSize: 15, color: COLORS.ink, marginBottom: 6, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {getMatchLocation(match)}
                          </div>
                          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 6 }}>
                            <span style={{ background: COLORS.bgSoft, padding: '4px 10px', borderRadius: 8, fontSize: 12, color: COLORS.dark, fontWeight: 500 }}>
                              ⭐ {match.level_min}-{match.level_max}
                            </span>
                            <span style={{ fontSize: 12, color: ambiance.color, fontWeight: 500 }}>{ambiance.emoji} {ambiance.label}</span>
                          </div>
                          <div style={{ fontSize: 12, color: COLORS.muted }}>
                            Par {match.profiles?.name?.split(' ')[0] || 'Anonyme'}
                          </div>
                        </div>

                        {/* Avatars + places */}
                        <div className="card-right" style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8, flexShrink: 0 }}>
                          <div style={{ display: 'flex' }}>
                            {allSlots.map((player, idx) => <Avatar key={idx} player={player} size={34} overlap index={idx} />)}
                          </div>
                          <span style={{ 
                            fontSize: 12, 
                            color: COLORS.teal,
                            fontWeight: 700,
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4
                          }}>
                            <span style={{ width: 6, height: 6, borderRadius: '50%', background: COLORS.teal }} className="junto-dot" />
                            {spotsLeft} place{spotsLeft > 1 ? 's' : ''}
                          </span>
                        </div>
                      </div>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>

          {/* Boîte à idées - Mobile */}
          <div className="ideas-mobile">
            <Link href="/dashboard/ideas" style={{ textDecoration: 'none' }}>
              <div style={{
                background: COLORS.white,
                borderRadius: 16,
                padding: 18,
                border: `2px solid ${COLORS.border}`,
                display: 'flex',
                alignItems: 'center',
                gap: 14
              }}>
                <span style={{ fontSize: 28 }}>💡</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 600, color: COLORS.ink }}>Boîte à idées</div>
                  <div style={{ fontSize: 13, color: COLORS.gray }}>Propose des améliorations</div>
                </div>
                <span style={{ color: COLORS.muted, fontSize: 20 }}>›</span>
              </div>
            </Link>
          </div>
        </div>

        {/* SIDEBAR */}
        <aside className="sidebar">
          
          {/* Profil */}
          <div style={{ 
            background: COLORS.white, 
            borderRadius: 20, 
            padding: 22,
            border: `2px solid ${COLORS.border}`,
            textAlign: 'center',
            marginBottom: 18
          }}>
            <div style={{ 
              width: 64, height: 64, borderRadius: '50%', 
              background: profile?.avatar_url ? COLORS.bgSoft : COLORS.primary,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: COLORS.white, fontWeight: 700, fontSize: 24,
              margin: '0 auto 12px', overflow: 'hidden',
              border: `3px solid ${COLORS.white}`,
              boxShadow: `0 4px 12px ${COLORS.primaryGlow}`
            }}>
              {profile?.avatar_url 
                ? <img src={profile.avatar_url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : profile?.name?.[0]?.toUpperCase()
              }
            </div>
            <div style={{ fontSize: 18, fontWeight: 700, color: COLORS.ink }}>{profile?.name}</div>
            <div style={{ fontSize: 13, color: COLORS.gray, marginBottom: 16 }}>
              Niveau {profile?.level || '?'} · {profile?.city || 'Non renseigné'}
            </div>
            
            {/* Mini stats avec 4 couleurs */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
              {[
                { n: stats.total, l: 'Jouées', c: COLORS.primary },
                { n: stats.organized, l: 'Orga.', c: COLORS.secondary },
                { n: stats.wins, l: 'Wins', c: COLORS.teal }
              ].map((s, i) => (
                <div key={s.l} style={{ background: COLORS.bgSoft, borderRadius: 12, padding: '12px 8px' }}>
                  <div style={{ fontSize: 20, fontWeight: 700, color: s.c }}>{s.n}</div>
                  <div style={{ fontSize: 10, color: COLORS.muted, fontWeight: 500 }}>{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Joueurs favoris */}
          <div style={{ 
            background: COLORS.white, 
            borderRadius: 20, 
            padding: 22,
            border: `2px solid ${COLORS.border}`,
            marginBottom: 18
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3 style={{ fontSize: 15, fontWeight: 700, margin: 0, color: COLORS.ink }}>
                ⭐ Joueurs favoris
              </h3>
              <Link href="/dashboard/joueurs" style={{ fontSize: 12, color: COLORS.primary, textDecoration: 'none', fontWeight: 600 }}>
                Voir
              </Link>
            </div>
            
            {favoritePlayers.length === 0 ? (
              <p style={{ fontSize: 14, color: COLORS.muted, margin: 0 }}>Aucun favori</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {favoritePlayers.map((player, i) => (
                  <Link href={`/player/${player.id}`} key={player.id} style={{ textDecoration: 'none' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
                      <Avatar player={player} size={40} index={i} />
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.ink }}>{player.name}</div>
                        <div style={{ fontSize: 12, color: COLORS.muted }}>Niv. {player.level}</div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Boîte à idées */}
          <Link href="/dashboard/ideas" style={{ textDecoration: 'none' }}>
            <div style={{ 
              background: COLORS.white, 
              borderRadius: 20, 
              padding: 18,
              border: `2px solid ${COLORS.border}`,
              display: 'flex',
              alignItems: 'center',
              gap: 14,
              cursor: 'pointer'
            }}>
              <span style={{ fontSize: 28 }}>💡</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.ink }}>Boîte à idées</div>
                <div style={{ fontSize: 12, color: COLORS.muted }}>Propose des améliorations</div>
              </div>
              <span style={{ color: COLORS.muted }}>›</span>
            </div>
          </Link>
        </aside>
      </div>

      <style jsx global>{`
        @keyframes junto-breathe {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.4); opacity: 0.7; }
        }
        .junto-dot { animation: junto-breathe 3s ease-in-out infinite; }
        
        @keyframes junto-loading {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-12px); }
        }
        .junto-loading-dot { animation: junto-loading 1.4s ease-in-out infinite; }
        .junto-loading-dot:nth-child(1) { animation-delay: 0s; }
        .junto-loading-dot:nth-child(2) { animation-delay: 0.1s; }
        .junto-loading-dot:nth-child(3) { animation-delay: 0.2s; }
        .junto-loading-dot:nth-child(4) { animation-delay: 0.3s; }

        .page-container {
          display: flex;
          gap: 28px;
          max-width: 1100px;
          margin: 0 auto;
        }
        
        .main-column { flex: 1; min-width: 0; }
        .sidebar { width: 300px; flex-shrink: 0; display: none; }
        
        .hero-content {
          display: flex;
          flex-direction: column;
          gap: 18px;
        }
        
        .create-btn { align-self: flex-start; }
        
        .matches-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 14px;
        }
        
        .match-card:hover {
          border-color: ${COLORS.primary} !important;
          transform: translateY(-6px);
          box-shadow: 0 12px 24px rgba(0,0,0,0.08);
        }
        
        .available-card:hover {
          border-color: ${COLORS.primary} !important;
          transform: translateY(-4px);
          box-shadow: 0 12px 24px rgba(0,0,0,0.08);
        }
        
        .avatar-hover { transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
        .avatar-hover:hover { transform: translateY(-6px) scale(1.1); z-index: 10 !important; }
        
        .ideas-mobile { display: block; }
        
        .filters-row {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .filters-row::-webkit-scrollbar { display: none; }
        
        @media (min-width: 640px) {
          .matches-grid { grid-template-columns: repeat(2, 1fr); }
          .hero-content { flex-direction: row; justify-content: space-between; align-items: center; }
        }
        
        @media (min-width: 1024px) {
          .sidebar { display: block; }
          .matches-grid { grid-template-columns: repeat(3, 1fr); }
          .ideas-mobile { display: none; }
        }
      `}</style>
    </>
  )
}
